﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TempMoniter
{
    /// <summary>
    /// 温度实体类
    /// </summary>
    class TempData
    {
        public double Line_1 { get; set; }
        public double Line_2 { get; set; }
        public double Line_3 { get; set; }
        public double Line_4 { get; set; }
    }
}
