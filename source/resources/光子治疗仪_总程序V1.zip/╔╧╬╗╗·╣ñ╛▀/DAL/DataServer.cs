﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace TempMoniter
{
    /// <summary>
    /// 数据处理服务，包括数据转换和数据存储
    /// </summary>
    class DataServer
    {
        TempData Data = new TempData();//实体化数据类

        public TempData DataAnaly(string DataStr)
        {
            string[] DataArray = DataStr.Split('#');//拆分字符串并且序列化
            Data.Line_1 = Convert.ToDouble(DataArray[0]);
            Data.Line_2 = Convert.ToDouble(DataArray[1]);
            Data.Line_3 = Convert.ToDouble(DataArray[2]);
            Data.Line_4 = Convert.ToDouble(DataArray[3]);
            return Data;
        }

        public void SaveDate(int index,TempData data, string Model)
        {
            string fileName = DateTime.Now.ToString("yyyy-MM-dd") + "温度记录.txt";
            FileStream fs = new FileStream(@fileName, FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(index.ToString() + "---" + Model + "---" +
                data.Line_1.ToString() + "---" +
                data.Line_2.ToString() + "---" +
                data.Line_3.ToString() + "---" +
                data.Line_4.ToString() + "---" +
                DateTime.Now.ToLocalTime().ToString());
            sw.Close();
            fs.Close();
        }

    }
}
