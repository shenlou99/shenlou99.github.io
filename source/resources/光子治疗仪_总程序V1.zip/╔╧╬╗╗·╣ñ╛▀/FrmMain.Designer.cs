﻿
using System;
using TempMoniter;

namespace 上位机
{
    partial class FrmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.lb_ipaddress = new System.Windows.Forms.Label();
            this.btn_wangkouOPEN = new System.Windows.Forms.Button();
            this.lb_ipport = new System.Windows.Forms.Label();
            this.btn_wangkouCLOSE = new System.Windows.Forms.Button();
            this.gb_left_pwm = new System.Windows.Forms.GroupBox();
            this.btn_left_pwmdown = new System.Windows.Forms.Button();
            this.btn_left_pwmup = new System.Windows.Forms.Button();
            this.gb_left_temp = new System.Windows.Forms.GroupBox();
            this.rb_left_tempCLOSE = new System.Windows.Forms.RadioButton();
            this.rb_left_tempOPEN = new System.Windows.Forms.RadioButton();
            this.gb_right_pwm = new System.Windows.Forms.GroupBox();
            this.btn_right_pwmdown = new System.Windows.Forms.Button();
            this.btn_right_pwmup = new System.Windows.Forms.Button();
            this.gb_left_motor = new System.Windows.Forms.GroupBox();
            this.btn_left_motordown = new System.Windows.Forms.Button();
            this.btn_left_motorup = new System.Windows.Forms.Button();
            this.gb_right_motor = new System.Windows.Forms.GroupBox();
            this.btn_right_motordown = new System.Windows.Forms.Button();
            this.btn_right_motorup = new System.Windows.Forms.Button();
            this.gb_left_switch = new System.Windows.Forms.GroupBox();
            this.gb_left_ocswitch = new System.Windows.Forms.GroupBox();
            this.rb_left_stop = new System.Windows.Forms.RadioButton();
            this.rb_left_start = new System.Windows.Forms.RadioButton();
            this.gb_left_rbswitch = new System.Windows.Forms.GroupBox();
            this.rb_left_blue = new System.Windows.Forms.RadioButton();
            this.rb_left_red = new System.Windows.Forms.RadioButton();
            this.cb_port = new System.Windows.Forms.ComboBox();
            this.lb_usb = new System.Windows.Forms.Label();
            this.pb_sw_upgrade = new System.Windows.Forms.ProgressBar();
            this.gb_right_temp = new System.Windows.Forms.GroupBox();
            this.rb_right_tempCLOSE = new System.Windows.Forms.RadioButton();
            this.rb_right_tempOPEN = new System.Windows.Forms.RadioButton();
            this.gb_right_switch = new System.Windows.Forms.GroupBox();
            this.gb_right_ocswitch = new System.Windows.Forms.GroupBox();
            this.rb_right_stop = new System.Windows.Forms.RadioButton();
            this.rb_right_start = new System.Windows.Forms.RadioButton();
            this.gb_right_rbswitch = new System.Windows.Forms.GroupBox();
            this.rb_right_blue = new System.Windows.Forms.RadioButton();
            this.rb_right_red = new System.Windows.Forms.RadioButton();
            this.gb_left_time = new System.Windows.Forms.GroupBox();
            this.btn_left_timedown = new System.Windows.Forms.Button();
            this.btn_left_timeup = new System.Windows.Forms.Button();
            this.lb_left_blueminute = new System.Windows.Forms.Label();
            this.lb_left_redminute = new System.Windows.Forms.Label();
            this.gb_right_time = new System.Windows.Forms.GroupBox();
            this.btn_right_timedown = new System.Windows.Forms.Button();
            this.btn_right_timeup = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.cht_temp = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.lv_temp = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.rtb_textshow = new System.Windows.Forms.RichTextBox();
            this.tb_ipaddress = new System.Windows.Forms.TextBox();
            this.tb_ipport = new System.Windows.Forms.TextBox();
            this.btn_send = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.rtb_send = new System.Windows.Forms.RichTextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.gb_pl = new System.Windows.Forms.GroupBox();
            this.gb_right_pl = new System.Windows.Forms.GroupBox();
            this.rb_right_lianxu = new System.Windows.Forms.RadioButton();
            this.rb_right_pinshan = new System.Windows.Forms.RadioButton();
            this.gb_left_pl = new System.Windows.Forms.GroupBox();
            this.rb_left_lianxu = new System.Windows.Forms.RadioButton();
            this.rb_left_pinshan = new System.Windows.Forms.RadioButton();
            this.rb_double_mode = new System.Windows.Forms.RadioButton();
            this.rb_single_mode = new System.Windows.Forms.RadioButton();
            this.gb_mode = new System.Windows.Forms.GroupBox();
            this.gb_left_red_time = new System.Windows.Forms.GroupBox();
            this.btn_left_red_timedown = new System.Windows.Forms.Button();
            this.btn_left_red_timeup = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.gb_left_blue_time = new System.Windows.Forms.GroupBox();
            this.btn_left_blue_timedown = new System.Windows.Forms.Button();
            this.btn_left_blue_timeup = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.gb_right_red_time = new System.Windows.Forms.GroupBox();
            this.btn_right_red_timedown = new System.Windows.Forms.Button();
            this.btn_right_red_timeup = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.gb_right_blue_time = new System.Windows.Forms.GroupBox();
            this.btn_right_blue_timedown = new System.Windows.Forms.Button();
            this.btn_right_blue_timeup = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.gb_double_left_time = new System.Windows.Forms.GroupBox();
            this.gb_double_right_time = new System.Windows.Forms.GroupBox();
            this.btn_sw_upgrade = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn_closeusb = new System.Windows.Forms.Button();
            this.btn_openusb = new System.Windows.Forms.Button();
            this.lb_process = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.btn_usb_send = new System.Windows.Forms.Button();
            this.gb_left_pwm.SuspendLayout();
            this.gb_left_temp.SuspendLayout();
            this.gb_right_pwm.SuspendLayout();
            this.gb_left_motor.SuspendLayout();
            this.gb_right_motor.SuspendLayout();
            this.gb_left_switch.SuspendLayout();
            this.gb_left_ocswitch.SuspendLayout();
            this.gb_left_rbswitch.SuspendLayout();
            this.gb_right_temp.SuspendLayout();
            this.gb_right_switch.SuspendLayout();
            this.gb_right_ocswitch.SuspendLayout();
            this.gb_right_rbswitch.SuspendLayout();
            this.gb_left_time.SuspendLayout();
            this.gb_right_time.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cht_temp)).BeginInit();
            this.gb_pl.SuspendLayout();
            this.gb_right_pl.SuspendLayout();
            this.gb_left_pl.SuspendLayout();
            this.gb_mode.SuspendLayout();
            this.gb_left_red_time.SuspendLayout();
            this.gb_left_blue_time.SuspendLayout();
            this.gb_right_red_time.SuspendLayout();
            this.gb_right_blue_time.SuspendLayout();
            this.gb_double_left_time.SuspendLayout();
            this.gb_double_right_time.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_ipaddress
            // 
            this.lb_ipaddress.AutoSize = true;
            this.lb_ipaddress.BackColor = System.Drawing.Color.Transparent;
            this.lb_ipaddress.Location = new System.Drawing.Point(13, 23);
            this.lb_ipaddress.Name = "lb_ipaddress";
            this.lb_ipaddress.Size = new System.Drawing.Size(41, 12);
            this.lb_ipaddress.TabIndex = 0;
            this.lb_ipaddress.Text = "目的IP";
            // 
            // btn_wangkouOPEN
            // 
            this.btn_wangkouOPEN.BackColor = System.Drawing.Color.Transparent;
            this.btn_wangkouOPEN.Location = new System.Drawing.Point(13, 92);
            this.btn_wangkouOPEN.Name = "btn_wangkouOPEN";
            this.btn_wangkouOPEN.Size = new System.Drawing.Size(71, 23);
            this.btn_wangkouOPEN.TabIndex = 1;
            this.btn_wangkouOPEN.Text = "打开网口";
            this.btn_wangkouOPEN.UseVisualStyleBackColor = false;
            this.btn_wangkouOPEN.Click += new System.EventHandler(this.btn_wangkouOPEN_Click);
            // 
            // lb_ipport
            // 
            this.lb_ipport.AutoSize = true;
            this.lb_ipport.BackColor = System.Drawing.Color.Transparent;
            this.lb_ipport.Location = new System.Drawing.Point(11, 60);
            this.lb_ipport.Name = "lb_ipport";
            this.lb_ipport.Size = new System.Drawing.Size(53, 12);
            this.lb_ipport.TabIndex = 2;
            this.lb_ipport.Text = "目的端口";
            // 
            // btn_wangkouCLOSE
            // 
            this.btn_wangkouCLOSE.BackColor = System.Drawing.Color.Transparent;
            this.btn_wangkouCLOSE.Location = new System.Drawing.Point(96, 92);
            this.btn_wangkouCLOSE.Name = "btn_wangkouCLOSE";
            this.btn_wangkouCLOSE.Size = new System.Drawing.Size(81, 23);
            this.btn_wangkouCLOSE.TabIndex = 6;
            this.btn_wangkouCLOSE.Text = "关闭网口";
            this.btn_wangkouCLOSE.UseVisualStyleBackColor = false;
            this.btn_wangkouCLOSE.Click += new System.EventHandler(this.btn_wangkouCLOSE_Click);
            // 
            // gb_left_pwm
            // 
            this.gb_left_pwm.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gb_left_pwm.Controls.Add(this.btn_left_pwmdown);
            this.gb_left_pwm.Controls.Add(this.btn_left_pwmup);
            this.gb_left_pwm.Location = new System.Drawing.Point(210, 568);
            this.gb_left_pwm.Name = "gb_left_pwm";
            this.gb_left_pwm.Size = new System.Drawing.Size(124, 96);
            this.gb_left_pwm.TabIndex = 8;
            this.gb_left_pwm.TabStop = false;
            this.gb_left_pwm.Text = "左光能量控制";
            // 
            // btn_left_pwmdown
            // 
            this.btn_left_pwmdown.Location = new System.Drawing.Point(22, 58);
            this.btn_left_pwmdown.Name = "btn_left_pwmdown";
            this.btn_left_pwmdown.Size = new System.Drawing.Size(75, 23);
            this.btn_left_pwmdown.TabIndex = 5;
            this.btn_left_pwmdown.Text = "能量-";
            this.btn_left_pwmdown.UseVisualStyleBackColor = true;
            this.btn_left_pwmdown.Click += new System.EventHandler(this.btn_left_pwmdown_Click);
            // 
            // btn_left_pwmup
            // 
            this.btn_left_pwmup.Location = new System.Drawing.Point(22, 20);
            this.btn_left_pwmup.Name = "btn_left_pwmup";
            this.btn_left_pwmup.Size = new System.Drawing.Size(75, 23);
            this.btn_left_pwmup.TabIndex = 4;
            this.btn_left_pwmup.Text = "能量+";
            this.btn_left_pwmup.UseVisualStyleBackColor = true;
            this.btn_left_pwmup.Click += new System.EventHandler(this.btn_left_pwmup_Click);
            // 
            // gb_left_temp
            // 
            this.gb_left_temp.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gb_left_temp.Controls.Add(this.rb_left_tempCLOSE);
            this.gb_left_temp.Controls.Add(this.rb_left_tempOPEN);
            this.gb_left_temp.Location = new System.Drawing.Point(355, 568);
            this.gb_left_temp.Name = "gb_left_temp";
            this.gb_left_temp.Size = new System.Drawing.Size(132, 96);
            this.gb_left_temp.TabIndex = 9;
            this.gb_left_temp.TabStop = false;
            this.gb_left_temp.Text = "左光温度显示";
            // 
            // rb_left_tempCLOSE
            // 
            this.rb_left_tempCLOSE.AutoSize = true;
            this.rb_left_tempCLOSE.Location = new System.Drawing.Point(33, 58);
            this.rb_left_tempCLOSE.Name = "rb_left_tempCLOSE";
            this.rb_left_tempCLOSE.Size = new System.Drawing.Size(71, 16);
            this.rb_left_tempCLOSE.TabIndex = 1;
            this.rb_left_tempCLOSE.TabStop = true;
            this.rb_left_tempCLOSE.Text = "停止温度";
            this.rb_left_tempCLOSE.UseVisualStyleBackColor = true;
            this.rb_left_tempCLOSE.Click += new System.EventHandler(this.rb_left_tempCLOSE_Click);
            // 
            // rb_left_tempOPEN
            // 
            this.rb_left_tempOPEN.AutoSize = true;
            this.rb_left_tempOPEN.Location = new System.Drawing.Point(33, 24);
            this.rb_left_tempOPEN.Name = "rb_left_tempOPEN";
            this.rb_left_tempOPEN.Size = new System.Drawing.Size(71, 16);
            this.rb_left_tempOPEN.TabIndex = 0;
            this.rb_left_tempOPEN.TabStop = true;
            this.rb_left_tempOPEN.Text = "显示温度";
            this.rb_left_tempOPEN.UseVisualStyleBackColor = true;
            this.rb_left_tempOPEN.Click += new System.EventHandler(this.rb_left_tempOPEN_Click);
            // 
            // gb_right_pwm
            // 
            this.gb_right_pwm.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gb_right_pwm.Controls.Add(this.btn_right_pwmdown);
            this.gb_right_pwm.Controls.Add(this.btn_right_pwmup);
            this.gb_right_pwm.Location = new System.Drawing.Point(777, 568);
            this.gb_right_pwm.Name = "gb_right_pwm";
            this.gb_right_pwm.Size = new System.Drawing.Size(124, 96);
            this.gb_right_pwm.TabIndex = 10;
            this.gb_right_pwm.TabStop = false;
            this.gb_right_pwm.Text = "右光能量控制";
            // 
            // btn_right_pwmdown
            // 
            this.btn_right_pwmdown.Location = new System.Drawing.Point(22, 54);
            this.btn_right_pwmdown.Name = "btn_right_pwmdown";
            this.btn_right_pwmdown.Size = new System.Drawing.Size(75, 23);
            this.btn_right_pwmdown.TabIndex = 5;
            this.btn_right_pwmdown.Text = "能量-";
            this.btn_right_pwmdown.UseVisualStyleBackColor = true;
            this.btn_right_pwmdown.Click += new System.EventHandler(this.btn_right_pwmdown_Click);
            // 
            // btn_right_pwmup
            // 
            this.btn_right_pwmup.Location = new System.Drawing.Point(22, 21);
            this.btn_right_pwmup.Name = "btn_right_pwmup";
            this.btn_right_pwmup.Size = new System.Drawing.Size(75, 23);
            this.btn_right_pwmup.TabIndex = 4;
            this.btn_right_pwmup.Text = "能量+";
            this.btn_right_pwmup.UseVisualStyleBackColor = true;
            this.btn_right_pwmup.Click += new System.EventHandler(this.btn_right_pwmup_Click);
            // 
            // gb_left_motor
            // 
            this.gb_left_motor.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gb_left_motor.Controls.Add(this.btn_left_motordown);
            this.gb_left_motor.Controls.Add(this.btn_left_motorup);
            this.gb_left_motor.Location = new System.Drawing.Point(210, 680);
            this.gb_left_motor.Name = "gb_left_motor";
            this.gb_left_motor.Size = new System.Drawing.Size(124, 87);
            this.gb_left_motor.TabIndex = 8;
            this.gb_left_motor.TabStop = false;
            this.gb_left_motor.Text = "左电机控制";
            this.gb_left_motor.Enter += new System.EventHandler(this.gb_left_motor_Enter);
            // 
            // btn_left_motordown
            // 
            this.btn_left_motordown.Location = new System.Drawing.Point(22, 58);
            this.btn_left_motordown.Name = "btn_left_motordown";
            this.btn_left_motordown.Size = new System.Drawing.Size(75, 23);
            this.btn_left_motordown.TabIndex = 5;
            this.btn_left_motordown.Text = "下降";
            this.btn_left_motordown.UseVisualStyleBackColor = true;
            this.btn_left_motordown.Click += new System.EventHandler(this.btn_left_motordown_Click);
            // 
            // btn_left_motorup
            // 
            this.btn_left_motorup.Location = new System.Drawing.Point(22, 20);
            this.btn_left_motorup.Name = "btn_left_motorup";
            this.btn_left_motorup.Size = new System.Drawing.Size(75, 23);
            this.btn_left_motorup.TabIndex = 4;
            this.btn_left_motorup.Text = "上升";
            this.btn_left_motorup.UseVisualStyleBackColor = true;
            this.btn_left_motorup.Click += new System.EventHandler(this.btn_left_motorup_Click);
            // 
            // gb_right_motor
            // 
            this.gb_right_motor.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gb_right_motor.Controls.Add(this.btn_right_motordown);
            this.gb_right_motor.Controls.Add(this.btn_right_motorup);
            this.gb_right_motor.Location = new System.Drawing.Point(777, 680);
            this.gb_right_motor.Name = "gb_right_motor";
            this.gb_right_motor.Size = new System.Drawing.Size(124, 87);
            this.gb_right_motor.TabIndex = 10;
            this.gb_right_motor.TabStop = false;
            this.gb_right_motor.Text = "右电机控制";
            // 
            // btn_right_motordown
            // 
            this.btn_right_motordown.Location = new System.Drawing.Point(22, 54);
            this.btn_right_motordown.Name = "btn_right_motordown";
            this.btn_right_motordown.Size = new System.Drawing.Size(75, 23);
            this.btn_right_motordown.TabIndex = 5;
            this.btn_right_motordown.Text = "下降";
            this.btn_right_motordown.UseVisualStyleBackColor = true;
            this.btn_right_motordown.Click += new System.EventHandler(this.btn_right_motordown_Click);
            // 
            // btn_right_motorup
            // 
            this.btn_right_motorup.Location = new System.Drawing.Point(22, 21);
            this.btn_right_motorup.Name = "btn_right_motorup";
            this.btn_right_motorup.Size = new System.Drawing.Size(75, 23);
            this.btn_right_motorup.TabIndex = 4;
            this.btn_right_motorup.Text = "上升";
            this.btn_right_motorup.UseVisualStyleBackColor = true;
            this.btn_right_motorup.Click += new System.EventHandler(this.btn_right_motorup_Click);
            // 
            // gb_left_switch
            // 
            this.gb_left_switch.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gb_left_switch.Controls.Add(this.gb_left_ocswitch);
            this.gb_left_switch.Controls.Add(this.gb_left_rbswitch);
            this.gb_left_switch.Location = new System.Drawing.Point(508, 568);
            this.gb_left_switch.Name = "gb_left_switch";
            this.gb_left_switch.Size = new System.Drawing.Size(116, 199);
            this.gb_left_switch.TabIndex = 11;
            this.gb_left_switch.TabStop = false;
            this.gb_left_switch.Text = "左开关";
            // 
            // gb_left_ocswitch
            // 
            this.gb_left_ocswitch.Controls.Add(this.rb_left_stop);
            this.gb_left_ocswitch.Controls.Add(this.rb_left_start);
            this.gb_left_ocswitch.Location = new System.Drawing.Point(7, 112);
            this.gb_left_ocswitch.Name = "gb_left_ocswitch";
            this.gb_left_ocswitch.Size = new System.Drawing.Size(97, 75);
            this.gb_left_ocswitch.TabIndex = 1;
            this.gb_left_ocswitch.TabStop = false;
            this.gb_left_ocswitch.Text = "启动/停止";
            // 
            // rb_left_stop
            // 
            this.rb_left_stop.AutoSize = true;
            this.rb_left_stop.Location = new System.Drawing.Point(25, 53);
            this.rb_left_stop.Name = "rb_left_stop";
            this.rb_left_stop.Size = new System.Drawing.Size(47, 16);
            this.rb_left_stop.TabIndex = 1;
            this.rb_left_stop.TabStop = true;
            this.rb_left_stop.Text = "停止";
            this.rb_left_stop.UseVisualStyleBackColor = true;
            this.rb_left_stop.Click += new System.EventHandler(this.rb_left_stop_Click);
            // 
            // rb_left_start
            // 
            this.rb_left_start.AutoSize = true;
            this.rb_left_start.Location = new System.Drawing.Point(25, 20);
            this.rb_left_start.Name = "rb_left_start";
            this.rb_left_start.Size = new System.Drawing.Size(47, 16);
            this.rb_left_start.TabIndex = 0;
            this.rb_left_start.TabStop = true;
            this.rb_left_start.Text = "启动";
            this.rb_left_start.UseVisualStyleBackColor = true;
            this.rb_left_start.Click += new System.EventHandler(this.rb_left_start_Click);
            // 
            // gb_left_rbswitch
            // 
            this.gb_left_rbswitch.Controls.Add(this.rb_left_blue);
            this.gb_left_rbswitch.Controls.Add(this.rb_left_red);
            this.gb_left_rbswitch.Location = new System.Drawing.Point(7, 21);
            this.gb_left_rbswitch.Name = "gb_left_rbswitch";
            this.gb_left_rbswitch.Size = new System.Drawing.Size(97, 75);
            this.gb_left_rbswitch.TabIndex = 0;
            this.gb_left_rbswitch.TabStop = false;
            this.gb_left_rbswitch.Text = "红蓝光选择";
            // 
            // rb_left_blue
            // 
            this.rb_left_blue.AutoSize = true;
            this.rb_left_blue.Location = new System.Drawing.Point(25, 53);
            this.rb_left_blue.Name = "rb_left_blue";
            this.rb_left_blue.Size = new System.Drawing.Size(47, 16);
            this.rb_left_blue.TabIndex = 1;
            this.rb_left_blue.TabStop = true;
            this.rb_left_blue.Text = "蓝光";
            this.rb_left_blue.UseVisualStyleBackColor = true;
            this.rb_left_blue.Click += new System.EventHandler(this.rb_left_blue_Click);
            // 
            // rb_left_red
            // 
            this.rb_left_red.AutoSize = true;
            this.rb_left_red.Location = new System.Drawing.Point(25, 20);
            this.rb_left_red.Name = "rb_left_red";
            this.rb_left_red.Size = new System.Drawing.Size(47, 16);
            this.rb_left_red.TabIndex = 0;
            this.rb_left_red.TabStop = true;
            this.rb_left_red.Text = "红光";
            this.rb_left_red.UseVisualStyleBackColor = true;
            this.rb_left_red.Click += new System.EventHandler(this.rb_left_red_Click);
            // 
            // cb_port
            // 
            this.cb_port.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.cb_port.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_port.ForeColor = System.Drawing.Color.Black;
            this.cb_port.FormattingEnabled = true;
            this.cb_port.Location = new System.Drawing.Point(267, 21);
            this.cb_port.Name = "cb_port";
            this.cb_port.Size = new System.Drawing.Size(155, 20);
            this.cb_port.TabIndex = 14;
            // 
            // lb_usb
            // 
            this.lb_usb.AutoSize = true;
            this.lb_usb.BackColor = System.Drawing.Color.Transparent;
            this.lb_usb.Location = new System.Drawing.Point(214, 25);
            this.lb_usb.Name = "lb_usb";
            this.lb_usb.Size = new System.Drawing.Size(47, 12);
            this.lb_usb.TabIndex = 13;
            this.lb_usb.Text = "USB接口";
            // 
            // pb_sw_upgrade
            // 
            this.pb_sw_upgrade.BackColor = System.Drawing.Color.LightGray;
            this.pb_sw_upgrade.Location = new System.Drawing.Point(267, 92);
            this.pb_sw_upgrade.Name = "pb_sw_upgrade";
            this.pb_sw_upgrade.Size = new System.Drawing.Size(155, 22);
            this.pb_sw_upgrade.TabIndex = 15;
            // 
            // gb_right_temp
            // 
            this.gb_right_temp.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gb_right_temp.Controls.Add(this.rb_right_tempCLOSE);
            this.gb_right_temp.Controls.Add(this.rb_right_tempOPEN);
            this.gb_right_temp.Location = new System.Drawing.Point(922, 568);
            this.gb_right_temp.Name = "gb_right_temp";
            this.gb_right_temp.Size = new System.Drawing.Size(132, 96);
            this.gb_right_temp.TabIndex = 16;
            this.gb_right_temp.TabStop = false;
            this.gb_right_temp.Text = "右光温度显示控制";
            // 
            // rb_right_tempCLOSE
            // 
            this.rb_right_tempCLOSE.AutoSize = true;
            this.rb_right_tempCLOSE.Location = new System.Drawing.Point(33, 58);
            this.rb_right_tempCLOSE.Name = "rb_right_tempCLOSE";
            this.rb_right_tempCLOSE.Size = new System.Drawing.Size(71, 16);
            this.rb_right_tempCLOSE.TabIndex = 1;
            this.rb_right_tempCLOSE.TabStop = true;
            this.rb_right_tempCLOSE.Text = "停止温度";
            this.rb_right_tempCLOSE.UseVisualStyleBackColor = true;
            this.rb_right_tempCLOSE.Click += new System.EventHandler(this.rb_right_tempCLOSE_Click);
            // 
            // rb_right_tempOPEN
            // 
            this.rb_right_tempOPEN.AutoSize = true;
            this.rb_right_tempOPEN.Location = new System.Drawing.Point(33, 24);
            this.rb_right_tempOPEN.Name = "rb_right_tempOPEN";
            this.rb_right_tempOPEN.Size = new System.Drawing.Size(71, 16);
            this.rb_right_tempOPEN.TabIndex = 0;
            this.rb_right_tempOPEN.TabStop = true;
            this.rb_right_tempOPEN.Text = "显示温度";
            this.rb_right_tempOPEN.UseVisualStyleBackColor = true;
            this.rb_right_tempOPEN.Click += new System.EventHandler(this.rb_right_tempOPEN_Click);
            // 
            // gb_right_switch
            // 
            this.gb_right_switch.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gb_right_switch.Controls.Add(this.gb_right_ocswitch);
            this.gb_right_switch.Controls.Add(this.gb_right_rbswitch);
            this.gb_right_switch.Location = new System.Drawing.Point(646, 568);
            this.gb_right_switch.Name = "gb_right_switch";
            this.gb_right_switch.Size = new System.Drawing.Size(116, 199);
            this.gb_right_switch.TabIndex = 11;
            this.gb_right_switch.TabStop = false;
            this.gb_right_switch.Text = "右开关";
            // 
            // gb_right_ocswitch
            // 
            this.gb_right_ocswitch.Controls.Add(this.rb_right_stop);
            this.gb_right_ocswitch.Controls.Add(this.rb_right_start);
            this.gb_right_ocswitch.Location = new System.Drawing.Point(7, 112);
            this.gb_right_ocswitch.Name = "gb_right_ocswitch";
            this.gb_right_ocswitch.Size = new System.Drawing.Size(97, 75);
            this.gb_right_ocswitch.TabIndex = 1;
            this.gb_right_ocswitch.TabStop = false;
            this.gb_right_ocswitch.Text = "启动/停止";
            // 
            // rb_right_stop
            // 
            this.rb_right_stop.AutoSize = true;
            this.rb_right_stop.Location = new System.Drawing.Point(25, 53);
            this.rb_right_stop.Name = "rb_right_stop";
            this.rb_right_stop.Size = new System.Drawing.Size(47, 16);
            this.rb_right_stop.TabIndex = 1;
            this.rb_right_stop.TabStop = true;
            this.rb_right_stop.Text = "停止";
            this.rb_right_stop.UseVisualStyleBackColor = true;
            this.rb_right_stop.Click += new System.EventHandler(this.rb_right_stop_Click);
            // 
            // rb_right_start
            // 
            this.rb_right_start.AutoSize = true;
            this.rb_right_start.Location = new System.Drawing.Point(25, 20);
            this.rb_right_start.Name = "rb_right_start";
            this.rb_right_start.Size = new System.Drawing.Size(47, 16);
            this.rb_right_start.TabIndex = 0;
            this.rb_right_start.TabStop = true;
            this.rb_right_start.Text = "启动";
            this.rb_right_start.UseVisualStyleBackColor = true;
            this.rb_right_start.Click += new System.EventHandler(this.rb_right_start_Click);
            // 
            // gb_right_rbswitch
            // 
            this.gb_right_rbswitch.Controls.Add(this.rb_right_blue);
            this.gb_right_rbswitch.Controls.Add(this.rb_right_red);
            this.gb_right_rbswitch.Location = new System.Drawing.Point(7, 21);
            this.gb_right_rbswitch.Name = "gb_right_rbswitch";
            this.gb_right_rbswitch.Size = new System.Drawing.Size(97, 75);
            this.gb_right_rbswitch.TabIndex = 0;
            this.gb_right_rbswitch.TabStop = false;
            this.gb_right_rbswitch.Text = "红蓝光选择";
            // 
            // rb_right_blue
            // 
            this.rb_right_blue.AutoSize = true;
            this.rb_right_blue.Location = new System.Drawing.Point(25, 53);
            this.rb_right_blue.Name = "rb_right_blue";
            this.rb_right_blue.Size = new System.Drawing.Size(47, 16);
            this.rb_right_blue.TabIndex = 1;
            this.rb_right_blue.TabStop = true;
            this.rb_right_blue.Text = "蓝光";
            this.rb_right_blue.UseVisualStyleBackColor = true;
            this.rb_right_blue.Click += new System.EventHandler(this.rb_right_blue_Click);
            // 
            // rb_right_red
            // 
            this.rb_right_red.AutoSize = true;
            this.rb_right_red.Location = new System.Drawing.Point(25, 20);
            this.rb_right_red.Name = "rb_right_red";
            this.rb_right_red.Size = new System.Drawing.Size(47, 16);
            this.rb_right_red.TabIndex = 0;
            this.rb_right_red.TabStop = true;
            this.rb_right_red.Text = "红光";
            this.rb_right_red.UseVisualStyleBackColor = true;
            this.rb_right_red.Click += new System.EventHandler(this.rb_right_red_Click);
            // 
            // gb_left_time
            // 
            this.gb_left_time.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gb_left_time.Controls.Add(this.btn_left_timedown);
            this.gb_left_time.Controls.Add(this.btn_left_timeup);
            this.gb_left_time.Controls.Add(this.lb_left_blueminute);
            this.gb_left_time.Controls.Add(this.lb_left_redminute);
            this.gb_left_time.Location = new System.Drawing.Point(355, 680);
            this.gb_left_time.Name = "gb_left_time";
            this.gb_left_time.Size = new System.Drawing.Size(132, 87);
            this.gb_left_time.TabIndex = 9;
            this.gb_left_time.TabStop = false;
            this.gb_left_time.Text = "左定时";
            // 
            // btn_left_timedown
            // 
            this.btn_left_timedown.Location = new System.Drawing.Point(15, 58);
            this.btn_left_timedown.Name = "btn_left_timedown";
            this.btn_left_timedown.Size = new System.Drawing.Size(69, 23);
            this.btn_left_timedown.TabIndex = 5;
            this.btn_left_timedown.Text = "时间-";
            this.btn_left_timedown.UseVisualStyleBackColor = true;
            this.btn_left_timedown.Click += new System.EventHandler(this.btn_left_timedown_Click);
            // 
            // btn_left_timeup
            // 
            this.btn_left_timeup.Location = new System.Drawing.Point(15, 19);
            this.btn_left_timeup.Name = "btn_left_timeup";
            this.btn_left_timeup.Size = new System.Drawing.Size(69, 23);
            this.btn_left_timeup.TabIndex = 4;
            this.btn_left_timeup.Text = "时间+";
            this.btn_left_timeup.UseVisualStyleBackColor = true;
            this.btn_left_timeup.Click += new System.EventHandler(this.btn_left_timeup_Click);
            // 
            // lb_left_blueminute
            // 
            this.lb_left_blueminute.AutoSize = true;
            this.lb_left_blueminute.Location = new System.Drawing.Point(79, 64);
            this.lb_left_blueminute.Name = "lb_left_blueminute";
            this.lb_left_blueminute.Size = new System.Drawing.Size(47, 12);
            this.lb_left_blueminute.TabIndex = 3;
            this.lb_left_blueminute.Text = "（0-99)";
            // 
            // lb_left_redminute
            // 
            this.lb_left_redminute.AutoSize = true;
            this.lb_left_redminute.Location = new System.Drawing.Point(79, 24);
            this.lb_left_redminute.Name = "lb_left_redminute";
            this.lb_left_redminute.Size = new System.Drawing.Size(47, 12);
            this.lb_left_redminute.TabIndex = 3;
            this.lb_left_redminute.Text = "（0-99)";
            // 
            // gb_right_time
            // 
            this.gb_right_time.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gb_right_time.Controls.Add(this.btn_right_timedown);
            this.gb_right_time.Controls.Add(this.btn_right_timeup);
            this.gb_right_time.Controls.Add(this.label4);
            this.gb_right_time.Controls.Add(this.label3);
            this.gb_right_time.Location = new System.Drawing.Point(922, 680);
            this.gb_right_time.Name = "gb_right_time";
            this.gb_right_time.Size = new System.Drawing.Size(132, 87);
            this.gb_right_time.TabIndex = 16;
            this.gb_right_time.TabStop = false;
            this.gb_right_time.Text = "右定时";
            // 
            // btn_right_timedown
            // 
            this.btn_right_timedown.Location = new System.Drawing.Point(15, 58);
            this.btn_right_timedown.Name = "btn_right_timedown";
            this.btn_right_timedown.Size = new System.Drawing.Size(68, 23);
            this.btn_right_timedown.TabIndex = 5;
            this.btn_right_timedown.Text = "时间-";
            this.btn_right_timedown.UseVisualStyleBackColor = true;
            this.btn_right_timedown.Click += new System.EventHandler(this.btn_right_timedown_Click);
            // 
            // btn_right_timeup
            // 
            this.btn_right_timeup.Location = new System.Drawing.Point(15, 21);
            this.btn_right_timeup.Name = "btn_right_timeup";
            this.btn_right_timeup.Size = new System.Drawing.Size(68, 23);
            this.btn_right_timeup.TabIndex = 4;
            this.btn_right_timeup.Text = "时间+";
            this.btn_right_timeup.UseVisualStyleBackColor = true;
            this.btn_right_timeup.Click += new System.EventHandler(this.btn_right_timeup_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(79, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "（0-99)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(79, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "（0-99)";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightGray;
            this.button3.Location = new System.Drawing.Point(979, 27);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 34);
            this.button3.TabIndex = 7;
            this.button3.Text = "退出应用";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // cht_temp
            // 
            chartArea1.AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.True;
            chartArea1.AxisX.Interval = 1D;
            chartArea1.AxisX.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Minutes;
            chartArea1.AxisX.LabelStyle.Format = "HH:mm:ss";
            chartArea1.AxisX.LabelStyle.Interval = 1D;
            chartArea1.AxisX.LabelStyle.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Minutes;
            chartArea1.AxisX.MajorGrid.Interval = 1D;
            chartArea1.AxisX.MajorGrid.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Auto;
            chartArea1.AxisX.ScaleView.Size = 10D;
            chartArea1.AxisX.Title = "时间";
            chartArea1.AxisY.Maximum = 75D;
            chartArea1.AxisY.Title = "温度/℃";
            chartArea1.CursorX.IsUserEnabled = true;
            chartArea1.CursorX.IsUserSelectionEnabled = true;
            chartArea1.Name = "ChartArea1";
            this.cht_temp.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.cht_temp.Legends.Add(legend1);
            this.cht_temp.Location = new System.Drawing.Point(30, 27);
            this.cht_temp.Name = "cht_temp";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.IsValueShownAsLabel = true;
            series1.Legend = "Legend1";
            series1.MarkerBorderColor = System.Drawing.Color.White;
            series1.MarkerColor = System.Drawing.SystemColors.MenuHighlight;
            series1.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series1.Name = "左光";
            series1.XValueMember = "time";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            series1.YValueMembers = "left_Temp";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series2.IsValueShownAsLabel = true;
            series2.Legend = "Legend1";
            series2.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Diamond;
            series2.Name = "右光";
            series2.XValueMember = "time";
            series2.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            series2.YValueMembers = "right_Temp";
            this.cht_temp.Series.Add(series1);
            this.cht_temp.Series.Add(series2);
            this.cht_temp.Size = new System.Drawing.Size(515, 247);
            this.cht_temp.TabIndex = 0;
            this.cht_temp.Text = "Temp";
            title1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            title1.Name = "title_temp";
            title1.Text = "温度监控";
            this.cht_temp.Titles.Add(title1);
            // 
            // lv_temp
            // 
            this.lv_temp.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lv_temp.HideSelection = false;
            this.lv_temp.Location = new System.Drawing.Point(30, 305);
            this.lv_temp.Name = "lv_temp";
            this.lv_temp.Size = new System.Drawing.Size(515, 120);
            this.lv_temp.TabIndex = 17;
            this.lv_temp.UseCompatibleStateImageBehavior = false;
            this.lv_temp.UseWaitCursor = true;
            this.lv_temp.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "序号";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "实时温度";
            this.columnHeader2.Width = 100;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "采集时间";
            this.columnHeader3.Width = 307;
            // 
            // rtb_textshow
            // 
            this.rtb_textshow.Location = new System.Drawing.Point(588, 27);
            this.rtb_textshow.Name = "rtb_textshow";
            this.rtb_textshow.Size = new System.Drawing.Size(384, 247);
            this.rtb_textshow.TabIndex = 18;
            this.rtb_textshow.Text = "";
            // 
            // tb_ipaddress
            // 
            this.tb_ipaddress.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tb_ipaddress.Location = new System.Drawing.Point(70, 20);
            this.tb_ipaddress.Name = "tb_ipaddress";
            this.tb_ipaddress.Size = new System.Drawing.Size(107, 21);
            this.tb_ipaddress.TabIndex = 1;
            // 
            // tb_ipport
            // 
            this.tb_ipport.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tb_ipport.Location = new System.Drawing.Point(70, 57);
            this.tb_ipport.Name = "tb_ipport";
            this.tb_ipport.Size = new System.Drawing.Size(107, 21);
            this.tb_ipport.TabIndex = 1;
            // 
            // btn_send
            // 
            this.btn_send.Location = new System.Drawing.Point(979, 402);
            this.btn_send.Name = "btn_send";
            this.btn_send.Size = new System.Drawing.Size(75, 23);
            this.btn_send.TabIndex = 19;
            this.btn_send.Text = "发送消息";
            this.btn_send.UseVisualStyleBackColor = true;
            this.btn_send.Click += new System.EventHandler(this.btn_send_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(979, 251);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(75, 23);
            this.btn_clear.TabIndex = 19;
            this.btn_clear.Text = "清空消息";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // rtb_send
            // 
            this.rtb_send.Location = new System.Drawing.Point(588, 305);
            this.rtb_send.Name = "rtb_send";
            this.rtb_send.Size = new System.Drawing.Size(385, 120);
            this.rtb_send.TabIndex = 18;
            this.rtb_send.Text = "";
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // gb_pl
            // 
            this.gb_pl.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gb_pl.Controls.Add(this.gb_right_pl);
            this.gb_pl.Controls.Add(this.gb_left_pl);
            this.gb_pl.Location = new System.Drawing.Point(31, 680);
            this.gb_pl.Name = "gb_pl";
            this.gb_pl.Size = new System.Drawing.Size(162, 87);
            this.gb_pl.TabIndex = 11;
            this.gb_pl.TabStop = false;
            this.gb_pl.Text = "频闪/连续";
            // 
            // gb_right_pl
            // 
            this.gb_right_pl.Controls.Add(this.rb_right_lianxu);
            this.gb_right_pl.Controls.Add(this.rb_right_pinshan);
            this.gb_right_pl.Location = new System.Drawing.Point(90, 15);
            this.gb_right_pl.Name = "gb_right_pl";
            this.gb_right_pl.Size = new System.Drawing.Size(56, 66);
            this.gb_right_pl.TabIndex = 1;
            this.gb_right_pl.TabStop = false;
            this.gb_right_pl.Text = "右侧";
            // 
            // rb_right_lianxu
            // 
            this.rb_right_lianxu.AutoSize = true;
            this.rb_right_lianxu.Location = new System.Drawing.Point(6, 42);
            this.rb_right_lianxu.Name = "rb_right_lianxu";
            this.rb_right_lianxu.Size = new System.Drawing.Size(47, 16);
            this.rb_right_lianxu.TabIndex = 1;
            this.rb_right_lianxu.TabStop = true;
            this.rb_right_lianxu.Text = "连续";
            this.rb_right_lianxu.UseVisualStyleBackColor = true;
            this.rb_right_lianxu.Click += new System.EventHandler(this.rb_right_lianxu_Click);
            // 
            // rb_right_pinshan
            // 
            this.rb_right_pinshan.AutoSize = true;
            this.rb_right_pinshan.Location = new System.Drawing.Point(6, 20);
            this.rb_right_pinshan.Name = "rb_right_pinshan";
            this.rb_right_pinshan.Size = new System.Drawing.Size(47, 16);
            this.rb_right_pinshan.TabIndex = 0;
            this.rb_right_pinshan.TabStop = true;
            this.rb_right_pinshan.Text = "频闪";
            this.rb_right_pinshan.UseVisualStyleBackColor = true;
            this.rb_right_pinshan.Click += new System.EventHandler(this.rb_right_pinshan_Click);
            // 
            // gb_left_pl
            // 
            this.gb_left_pl.Controls.Add(this.rb_left_lianxu);
            this.gb_left_pl.Controls.Add(this.rb_left_pinshan);
            this.gb_left_pl.Location = new System.Drawing.Point(20, 15);
            this.gb_left_pl.Name = "gb_left_pl";
            this.gb_left_pl.Size = new System.Drawing.Size(58, 66);
            this.gb_left_pl.TabIndex = 0;
            this.gb_left_pl.TabStop = false;
            this.gb_left_pl.Text = "左侧";
            // 
            // rb_left_lianxu
            // 
            this.rb_left_lianxu.AutoSize = true;
            this.rb_left_lianxu.Location = new System.Drawing.Point(6, 42);
            this.rb_left_lianxu.Name = "rb_left_lianxu";
            this.rb_left_lianxu.Size = new System.Drawing.Size(47, 16);
            this.rb_left_lianxu.TabIndex = 1;
            this.rb_left_lianxu.TabStop = true;
            this.rb_left_lianxu.Text = "连续";
            this.rb_left_lianxu.UseVisualStyleBackColor = true;
            this.rb_left_lianxu.Click += new System.EventHandler(this.rb_left_lianxu_Click);
            // 
            // rb_left_pinshan
            // 
            this.rb_left_pinshan.AutoSize = true;
            this.rb_left_pinshan.Location = new System.Drawing.Point(6, 20);
            this.rb_left_pinshan.Name = "rb_left_pinshan";
            this.rb_left_pinshan.Size = new System.Drawing.Size(47, 16);
            this.rb_left_pinshan.TabIndex = 0;
            this.rb_left_pinshan.TabStop = true;
            this.rb_left_pinshan.Text = "频闪";
            this.rb_left_pinshan.UseVisualStyleBackColor = true;
            this.rb_left_pinshan.Click += new System.EventHandler(this.rb_left_pinshan_Click);
            // 
            // rb_double_mode
            // 
            this.rb_double_mode.AutoSize = true;
            this.rb_double_mode.Location = new System.Drawing.Point(36, 54);
            this.rb_double_mode.Name = "rb_double_mode";
            this.rb_double_mode.Size = new System.Drawing.Size(59, 16);
            this.rb_double_mode.TabIndex = 1;
            this.rb_double_mode.TabStop = true;
            this.rb_double_mode.Text = "双模式";
            this.rb_double_mode.UseVisualStyleBackColor = true;
            this.rb_double_mode.Click += new System.EventHandler(this.rb_double_mode_Click);
            // 
            // rb_single_mode
            // 
            this.rb_single_mode.AutoSize = true;
            this.rb_single_mode.Location = new System.Drawing.Point(36, 28);
            this.rb_single_mode.Name = "rb_single_mode";
            this.rb_single_mode.Size = new System.Drawing.Size(59, 16);
            this.rb_single_mode.TabIndex = 0;
            this.rb_single_mode.TabStop = true;
            this.rb_single_mode.Text = "单模式";
            this.rb_single_mode.UseVisualStyleBackColor = true;
            this.rb_single_mode.Click += new System.EventHandler(this.rb_single_mode_Click);
            // 
            // gb_mode
            // 
            this.gb_mode.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gb_mode.Controls.Add(this.rb_single_mode);
            this.gb_mode.Controls.Add(this.rb_double_mode);
            this.gb_mode.Location = new System.Drawing.Point(31, 568);
            this.gb_mode.Name = "gb_mode";
            this.gb_mode.Size = new System.Drawing.Size(162, 96);
            this.gb_mode.TabIndex = 2;
            this.gb_mode.TabStop = false;
            this.gb_mode.Text = "模式";
            // 
            // gb_left_red_time
            // 
            this.gb_left_red_time.Controls.Add(this.btn_left_red_timedown);
            this.gb_left_red_time.Controls.Add(this.btn_left_red_timeup);
            this.gb_left_red_time.Controls.Add(this.label1);
            this.gb_left_red_time.Controls.Add(this.label2);
            this.gb_left_red_time.Location = new System.Drawing.Point(9, 20);
            this.gb_left_red_time.Name = "gb_left_red_time";
            this.gb_left_red_time.Size = new System.Drawing.Size(124, 87);
            this.gb_left_red_time.TabIndex = 9;
            this.gb_left_red_time.TabStop = false;
            this.gb_left_red_time.Text = "左红光定时";
            // 
            // btn_left_red_timedown
            // 
            this.btn_left_red_timedown.Location = new System.Drawing.Point(6, 59);
            this.btn_left_red_timedown.Name = "btn_left_red_timedown";
            this.btn_left_red_timedown.Size = new System.Drawing.Size(69, 23);
            this.btn_left_red_timedown.TabIndex = 5;
            this.btn_left_red_timedown.Text = "时间-";
            this.btn_left_red_timedown.UseVisualStyleBackColor = true;
            this.btn_left_red_timedown.Click += new System.EventHandler(this.btn_left_red_timedown_Click);
            // 
            // btn_left_red_timeup
            // 
            this.btn_left_red_timeup.Location = new System.Drawing.Point(6, 24);
            this.btn_left_red_timeup.Name = "btn_left_red_timeup";
            this.btn_left_red_timeup.Size = new System.Drawing.Size(69, 23);
            this.btn_left_red_timeup.TabIndex = 4;
            this.btn_left_red_timeup.Text = "时间+";
            this.btn_left_red_timeup.UseVisualStyleBackColor = true;
            this.btn_left_red_timeup.Click += new System.EventHandler(this.btn_left_red_timeup_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(71, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "（0-99)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(71, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "（0-99)";
            // 
            // gb_left_blue_time
            // 
            this.gb_left_blue_time.Controls.Add(this.btn_left_blue_timedown);
            this.gb_left_blue_time.Controls.Add(this.btn_left_blue_timeup);
            this.gb_left_blue_time.Controls.Add(this.label5);
            this.gb_left_blue_time.Controls.Add(this.label6);
            this.gb_left_blue_time.Location = new System.Drawing.Point(151, 20);
            this.gb_left_blue_time.Name = "gb_left_blue_time";
            this.gb_left_blue_time.Size = new System.Drawing.Size(122, 87);
            this.gb_left_blue_time.TabIndex = 9;
            this.gb_left_blue_time.TabStop = false;
            this.gb_left_blue_time.Text = "左蓝光定时";
            // 
            // btn_left_blue_timedown
            // 
            this.btn_left_blue_timedown.Location = new System.Drawing.Point(6, 58);
            this.btn_left_blue_timedown.Name = "btn_left_blue_timedown";
            this.btn_left_blue_timedown.Size = new System.Drawing.Size(66, 23);
            this.btn_left_blue_timedown.TabIndex = 5;
            this.btn_left_blue_timedown.Text = "时间-";
            this.btn_left_blue_timedown.UseVisualStyleBackColor = true;
            this.btn_left_blue_timedown.Click += new System.EventHandler(this.btn_left_blue_timedown_Click);
            // 
            // btn_left_blue_timeup
            // 
            this.btn_left_blue_timeup.Location = new System.Drawing.Point(6, 24);
            this.btn_left_blue_timeup.Name = "btn_left_blue_timeup";
            this.btn_left_blue_timeup.Size = new System.Drawing.Size(66, 23);
            this.btn_left_blue_timeup.TabIndex = 4;
            this.btn_left_blue_timeup.Text = "时间+";
            this.btn_left_blue_timeup.UseVisualStyleBackColor = true;
            this.btn_left_blue_timeup.Click += new System.EventHandler(this.btn_left_blue_timeup_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(69, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 12);
            this.label5.TabIndex = 3;
            this.label5.Text = "（0-99)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(69, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 12);
            this.label6.TabIndex = 3;
            this.label6.Text = "（0-99)";
            // 
            // gb_right_red_time
            // 
            this.gb_right_red_time.Controls.Add(this.btn_right_red_timedown);
            this.gb_right_red_time.Controls.Add(this.btn_right_red_timeup);
            this.gb_right_red_time.Controls.Add(this.label7);
            this.gb_right_red_time.Controls.Add(this.label8);
            this.gb_right_red_time.Location = new System.Drawing.Point(6, 20);
            this.gb_right_red_time.Name = "gb_right_red_time";
            this.gb_right_red_time.Size = new System.Drawing.Size(118, 87);
            this.gb_right_red_time.TabIndex = 9;
            this.gb_right_red_time.TabStop = false;
            this.gb_right_red_time.Text = "右红光定时";
            // 
            // btn_right_red_timedown
            // 
            this.btn_right_red_timedown.Location = new System.Drawing.Point(6, 59);
            this.btn_right_red_timedown.Name = "btn_right_red_timedown";
            this.btn_right_red_timedown.Size = new System.Drawing.Size(62, 23);
            this.btn_right_red_timedown.TabIndex = 5;
            this.btn_right_red_timedown.Text = "时间-";
            this.btn_right_red_timedown.UseVisualStyleBackColor = true;
            this.btn_right_red_timedown.Click += new System.EventHandler(this.btn_right_red_timedown_Click);
            // 
            // btn_right_red_timeup
            // 
            this.btn_right_red_timeup.Location = new System.Drawing.Point(6, 24);
            this.btn_right_red_timeup.Name = "btn_right_red_timeup";
            this.btn_right_red_timeup.Size = new System.Drawing.Size(62, 23);
            this.btn_right_red_timeup.TabIndex = 4;
            this.btn_right_red_timeup.Text = "时间+";
            this.btn_right_red_timeup.UseVisualStyleBackColor = true;
            this.btn_right_red_timeup.Click += new System.EventHandler(this.btn_right_red_timeup_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(65, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 12);
            this.label7.TabIndex = 3;
            this.label7.Text = "（0-99)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(65, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 12);
            this.label8.TabIndex = 3;
            this.label8.Text = "（0-99)";
            // 
            // gb_right_blue_time
            // 
            this.gb_right_blue_time.Controls.Add(this.btn_right_blue_timedown);
            this.gb_right_blue_time.Controls.Add(this.btn_right_blue_timeup);
            this.gb_right_blue_time.Controls.Add(this.label9);
            this.gb_right_blue_time.Controls.Add(this.label10);
            this.gb_right_blue_time.Location = new System.Drawing.Point(145, 20);
            this.gb_right_blue_time.Name = "gb_right_blue_time";
            this.gb_right_blue_time.Size = new System.Drawing.Size(126, 87);
            this.gb_right_blue_time.TabIndex = 9;
            this.gb_right_blue_time.TabStop = false;
            this.gb_right_blue_time.Text = "右蓝光定时";
            // 
            // btn_right_blue_timedown
            // 
            this.btn_right_blue_timedown.Location = new System.Drawing.Point(6, 58);
            this.btn_right_blue_timedown.Name = "btn_right_blue_timedown";
            this.btn_right_blue_timedown.Size = new System.Drawing.Size(67, 23);
            this.btn_right_blue_timedown.TabIndex = 5;
            this.btn_right_blue_timedown.Text = "时间-";
            this.btn_right_blue_timedown.UseVisualStyleBackColor = true;
            this.btn_right_blue_timedown.Click += new System.EventHandler(this.btn_right_blue_timedown_Click);
            // 
            // btn_right_blue_timeup
            // 
            this.btn_right_blue_timeup.Location = new System.Drawing.Point(6, 24);
            this.btn_right_blue_timeup.Name = "btn_right_blue_timeup";
            this.btn_right_blue_timeup.Size = new System.Drawing.Size(67, 23);
            this.btn_right_blue_timeup.TabIndex = 4;
            this.btn_right_blue_timeup.Text = "时间+";
            this.btn_right_blue_timeup.UseVisualStyleBackColor = true;
            this.btn_right_blue_timeup.Click += new System.EventHandler(this.btn_right_blue_timeup_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(70, 63);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 12);
            this.label9.TabIndex = 3;
            this.label9.Text = "（0-99)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(70, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 12);
            this.label10.TabIndex = 3;
            this.label10.Text = "（0-99)";
            // 
            // gb_double_left_time
            // 
            this.gb_double_left_time.BackColor = System.Drawing.Color.Goldenrod;
            this.gb_double_left_time.Controls.Add(this.gb_left_blue_time);
            this.gb_double_left_time.Controls.Add(this.gb_left_red_time);
            this.gb_double_left_time.Location = new System.Drawing.Point(477, 439);
            this.gb_double_left_time.Name = "gb_double_left_time";
            this.gb_double_left_time.Size = new System.Drawing.Size(285, 112);
            this.gb_double_left_time.TabIndex = 20;
            this.gb_double_left_time.TabStop = false;
            this.gb_double_left_time.Text = "左定时";
            // 
            // gb_double_right_time
            // 
            this.gb_double_right_time.BackColor = System.Drawing.Color.Goldenrod;
            this.gb_double_right_time.Controls.Add(this.gb_right_blue_time);
            this.gb_double_right_time.Controls.Add(this.gb_right_red_time);
            this.gb_double_right_time.Location = new System.Drawing.Point(777, 439);
            this.gb_double_right_time.Name = "gb_double_right_time";
            this.gb_double_right_time.Size = new System.Drawing.Size(277, 112);
            this.gb_double_right_time.TabIndex = 20;
            this.gb_double_right_time.TabStop = false;
            this.gb_double_right_time.Text = "右定时";
            // 
            // btn_sw_upgrade
            // 
            this.btn_sw_upgrade.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn_sw_upgrade.Location = new System.Drawing.Point(351, 55);
            this.btn_sw_upgrade.Name = "btn_sw_upgrade";
            this.btn_sw_upgrade.Size = new System.Drawing.Size(71, 23);
            this.btn_sw_upgrade.TabIndex = 21;
            this.btn_sw_upgrade.Text = "程序升级";
            this.btn_sw_upgrade.UseVisualStyleBackColor = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tb_ipaddress);
            this.groupBox4.Controls.Add(this.btn_sw_upgrade);
            this.groupBox4.Controls.Add(this.lb_ipaddress);
            this.groupBox4.Controls.Add(this.btn_closeusb);
            this.groupBox4.Controls.Add(this.btn_openusb);
            this.groupBox4.Controls.Add(this.btn_wangkouOPEN);
            this.groupBox4.Controls.Add(this.lb_ipport);
            this.groupBox4.Controls.Add(this.btn_wangkouCLOSE);
            this.groupBox4.Controls.Add(this.lb_process);
            this.groupBox4.Controls.Add(this.lb_usb);
            this.groupBox4.Controls.Add(this.cb_port);
            this.groupBox4.Controls.Add(this.pb_sw_upgrade);
            this.groupBox4.Controls.Add(this.tb_ipport);
            this.groupBox4.Location = new System.Drawing.Point(31, 437);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(428, 125);
            this.groupBox4.TabIndex = 22;
            this.groupBox4.TabStop = false;
            // 
            // btn_closeusb
            // 
            this.btn_closeusb.BackColor = System.Drawing.Color.Transparent;
            this.btn_closeusb.Location = new System.Drawing.Point(282, 55);
            this.btn_closeusb.Name = "btn_closeusb";
            this.btn_closeusb.Size = new System.Drawing.Size(63, 23);
            this.btn_closeusb.TabIndex = 1;
            this.btn_closeusb.Text = "关闭USB";
            this.btn_closeusb.UseVisualStyleBackColor = false;
            this.btn_closeusb.Click += new System.EventHandler(this.btn_closeusb_Click);
            // 
            // btn_openusb
            // 
            this.btn_openusb.BackColor = System.Drawing.Color.Transparent;
            this.btn_openusb.Location = new System.Drawing.Point(216, 55);
            this.btn_openusb.Name = "btn_openusb";
            this.btn_openusb.Size = new System.Drawing.Size(60, 23);
            this.btn_openusb.TabIndex = 1;
            this.btn_openusb.Text = "打开USB";
            this.btn_openusb.UseVisualStyleBackColor = false;
            this.btn_openusb.Click += new System.EventHandler(this.btn_openusb_Click);
            // 
            // lb_process
            // 
            this.lb_process.AutoSize = true;
            this.lb_process.BackColor = System.Drawing.Color.Transparent;
            this.lb_process.Location = new System.Drawing.Point(214, 97);
            this.lb_process.Name = "lb_process";
            this.lb_process.Size = new System.Drawing.Size(41, 12);
            this.lb_process.TabIndex = 13;
            this.lb_process.Text = "进度条";
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            // 
            // btn_usb_send
            // 
            this.btn_usb_send.Location = new System.Drawing.Point(979, 363);
            this.btn_usb_send.Name = "btn_usb_send";
            this.btn_usb_send.Size = new System.Drawing.Size(75, 23);
            this.btn_usb_send.TabIndex = 19;
            this.btn_usb_send.Text = "usb发送";
            this.btn_usb_send.UseVisualStyleBackColor = true;
            this.btn_usb_send.Click += new System.EventHandler(this.btn_usb_send_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1074, 779);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.gb_double_right_time);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.gb_double_left_time);
            this.Controls.Add(this.btn_usb_send);
            this.Controls.Add(this.btn_send);
            this.Controls.Add(this.gb_mode);
            this.Controls.Add(this.rtb_send);
            this.Controls.Add(this.rtb_textshow);
            this.Controls.Add(this.lv_temp);
            this.Controls.Add(this.cht_temp);
            this.Controls.Add(this.gb_right_time);
            this.Controls.Add(this.gb_right_temp);
            this.Controls.Add(this.gb_right_switch);
            this.Controls.Add(this.gb_pl);
            this.Controls.Add(this.gb_left_switch);
            this.Controls.Add(this.gb_right_motor);
            this.Controls.Add(this.gb_right_pwm);
            this.Controls.Add(this.gb_left_time);
            this.Controls.Add(this.gb_left_motor);
            this.Controls.Add(this.gb_left_temp);
            this.Controls.Add(this.gb_left_pwm);
            this.Controls.Add(this.button3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "光子治疗仪";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gb_left_pwm.ResumeLayout(false);
            this.gb_left_temp.ResumeLayout(false);
            this.gb_left_temp.PerformLayout();
            this.gb_right_pwm.ResumeLayout(false);
            this.gb_left_motor.ResumeLayout(false);
            this.gb_right_motor.ResumeLayout(false);
            this.gb_left_switch.ResumeLayout(false);
            this.gb_left_ocswitch.ResumeLayout(false);
            this.gb_left_ocswitch.PerformLayout();
            this.gb_left_rbswitch.ResumeLayout(false);
            this.gb_left_rbswitch.PerformLayout();
            this.gb_right_temp.ResumeLayout(false);
            this.gb_right_temp.PerformLayout();
            this.gb_right_switch.ResumeLayout(false);
            this.gb_right_ocswitch.ResumeLayout(false);
            this.gb_right_ocswitch.PerformLayout();
            this.gb_right_rbswitch.ResumeLayout(false);
            this.gb_right_rbswitch.PerformLayout();
            this.gb_left_time.ResumeLayout(false);
            this.gb_left_time.PerformLayout();
            this.gb_right_time.ResumeLayout(false);
            this.gb_right_time.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cht_temp)).EndInit();
            this.gb_pl.ResumeLayout(false);
            this.gb_right_pl.ResumeLayout(false);
            this.gb_right_pl.PerformLayout();
            this.gb_left_pl.ResumeLayout(false);
            this.gb_left_pl.PerformLayout();
            this.gb_mode.ResumeLayout(false);
            this.gb_mode.PerformLayout();
            this.gb_left_red_time.ResumeLayout(false);
            this.gb_left_red_time.PerformLayout();
            this.gb_left_blue_time.ResumeLayout(false);
            this.gb_left_blue_time.PerformLayout();
            this.gb_right_red_time.ResumeLayout(false);
            this.gb_right_red_time.PerformLayout();
            this.gb_right_blue_time.ResumeLayout(false);
            this.gb_right_blue_time.PerformLayout();
            this.gb_double_left_time.ResumeLayout(false);
            this.gb_double_right_time.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

     



        #endregion

        private System.Windows.Forms.Label lb_ipaddress;
        private System.Windows.Forms.Button btn_wangkouOPEN;
        private System.Windows.Forms.Label lb_ipport;
        private System.Windows.Forms.Button btn_wangkouCLOSE;
        private System.Windows.Forms.GroupBox gb_left_pwm;
        private System.Windows.Forms.GroupBox gb_left_temp;
        private System.Windows.Forms.RadioButton rb_left_tempCLOSE;
        private System.Windows.Forms.RadioButton rb_left_tempOPEN;
        private System.Windows.Forms.GroupBox gb_right_pwm;
        private System.Windows.Forms.Button btn_left_pwmdown;
        private System.Windows.Forms.Button btn_left_pwmup;
        private System.Windows.Forms.Button btn_right_pwmdown;
        private System.Windows.Forms.Button btn_right_pwmup;
        private System.Windows.Forms.GroupBox gb_left_motor;
        private System.Windows.Forms.Button btn_left_motordown;
        private System.Windows.Forms.Button btn_left_motorup;
        private System.Windows.Forms.GroupBox gb_right_motor;
        private System.Windows.Forms.Button btn_right_motordown;
        private System.Windows.Forms.Button btn_right_motorup;
        private System.Windows.Forms.GroupBox gb_left_switch;
        private System.Windows.Forms.RadioButton rb_left_stop;
        private System.Windows.Forms.RadioButton rb_left_start;
        private System.Windows.Forms.ComboBox cb_port;
        private System.Windows.Forms.Label lb_usb;
        private System.Windows.Forms.ProgressBar pb_sw_upgrade;
        private System.Windows.Forms.GroupBox gb_right_temp;
        private System.Windows.Forms.RadioButton rb_right_tempCLOSE;
        private System.Windows.Forms.RadioButton rb_right_tempOPEN;
        private System.Windows.Forms.GroupBox gb_left_ocswitch;
        private System.Windows.Forms.GroupBox gb_left_rbswitch;
        private System.Windows.Forms.RadioButton rb_left_blue;
        private System.Windows.Forms.RadioButton rb_left_red;
        private System.Windows.Forms.GroupBox gb_right_switch;
        private System.Windows.Forms.GroupBox gb_right_ocswitch;
        private System.Windows.Forms.RadioButton rb_right_stop;
        private System.Windows.Forms.RadioButton rb_right_start;
        private System.Windows.Forms.GroupBox gb_right_rbswitch;
        private System.Windows.Forms.RadioButton rb_right_blue;
        private System.Windows.Forms.RadioButton rb_right_red;
        private System.Windows.Forms.GroupBox gb_left_time;
        private System.Windows.Forms.GroupBox gb_right_time;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label lb_left_blueminute;
        private System.Windows.Forms.Label lb_left_redminute;
        private System.Windows.Forms.DataVisualization.Charting.Chart cht_temp;
        private System.Windows.Forms.ListView lv_temp;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.RichTextBox rtb_textshow;
        private System.Windows.Forms.TextBox tb_ipaddress;
        private System.Windows.Forms.TextBox tb_ipport;
        private System.Windows.Forms.Button btn_send;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.RichTextBox rtb_send;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_left_timedown;
        private System.Windows.Forms.Button btn_left_timeup;
        private System.Windows.Forms.Button btn_right_timedown;
        private System.Windows.Forms.Button btn_right_timeup;
        private System.Windows.Forms.GroupBox gb_pl;
        private System.Windows.Forms.GroupBox gb_right_pl;
        private System.Windows.Forms.RadioButton rb_right_lianxu;
        private System.Windows.Forms.RadioButton rb_right_pinshan;
        private System.Windows.Forms.GroupBox gb_left_pl;
        private System.Windows.Forms.RadioButton rb_left_lianxu;
        private System.Windows.Forms.RadioButton rb_left_pinshan;
        private System.Windows.Forms.GroupBox gb_double_right_time;
        private System.Windows.Forms.GroupBox gb_right_blue_time;
        private System.Windows.Forms.Button btn_right_blue_timedown;
        private System.Windows.Forms.Button btn_right_blue_timeup;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox gb_right_red_time;
        private System.Windows.Forms.Button btn_right_red_timedown;
        private System.Windows.Forms.Button btn_right_red_timeup;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox gb_double_left_time;
        private System.Windows.Forms.GroupBox gb_left_blue_time;
        private System.Windows.Forms.Button btn_left_blue_timedown;
        private System.Windows.Forms.Button btn_left_blue_timeup;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox gb_left_red_time;
        private System.Windows.Forms.Button btn_left_red_timedown;
        private System.Windows.Forms.Button btn_left_red_timeup;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gb_mode;
        private System.Windows.Forms.RadioButton rb_single_mode;
        private System.Windows.Forms.RadioButton rb_double_mode;
        private System.Windows.Forms.Button btn_sw_upgrade;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lb_process;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Button btn_closeusb;
        private System.Windows.Forms.Button btn_openusb;
        private System.Windows.Forms.Button btn_usb_send;
    }
}

