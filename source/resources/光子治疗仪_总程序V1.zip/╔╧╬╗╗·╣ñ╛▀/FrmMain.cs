﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Windows.Forms;
using TempMoniter;
using System.Net.Sockets;
using System.Threading;
using System.Net;
using Timer = System.Windows.Forms.Timer;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;

using LibUsbDotNet;
using LibUsbDotNet.Main;
using LibUsbDotNet.Info;
using LibUsbDotNet.Descriptors;
using LibUsbDotNet.LibUsb;
using LibUsbDotNet.WinUsb;
using System.Collections.ObjectModel;

namespace 上位机
{
    public partial class FrmMain : Form
    {
        
        public static int SFlag = 0;    //连接服务器成功标志
        Thread th1;     //声明一个线程
        public byte[] Send_Data = new byte[4];
        /*********TCP/IP编程变量定义*****/
        private IPAddress serverIP = IPAddress.Parse("127.0.0.1");             //默认本地回环IP
        public static Socket ClientSocket;  //声明负责通信的socket

        //定义网口数据接收数组
        byte[] receive = new byte[2];                           //存放左右温度

        //int left_temp_high, left_temp_low;                      //定义左光温度高低位
        int left_temp;                                          //左温度值

        //int right_temp_high, right_temp_low;                      //定义右光温度高低位
        int right_temp;                                          //右温度值

        int left_temp_flag;                                     //左温度显示标志位
        int right_temp_flag;

        #region  温度转换相关定义
        //short NTC_L;                                        //左电阻值
        //short NTC_R;                                        //右电阻值
        /*******
        const double Rp = 10000.0; //10K
        const double Tt = (273.15 + 25.0);//T2
        const double Bx = 3950.0f;//B
        const double Ka = 273.15;
        *******/
        //储存byte[]转换成string
        //string LEFT_TEMP ;
        //string WRITE_TEMP ;
        #endregion

        #region  队列定义
        /******
        private Queue<double> dataQueue = new Queue<double>(100);                   //定义队列存储温度值
        private Queue<double> dataQueue1 = new Queue<double>(100);
        ******/
        #endregion

        #region  chart显示数据相关定义
        //当前的总数据量
        int dataCounts = 0;
        //chart图显示的数据点数【默认值】
        //int chartShowPointCount = 100;
        //int minChartShowPointCount = 10;
        //chart图上的数据点放大缩小时，采用的step
        //int sizeStep = 10;
        #endregion


        public FrmMain()
        {
            InitializeComponent();
            //Initialize();
            
        }



        #region 串口初始化
        private void Initialize()
        {
            /********
            //获取电脑全部串口名称
            this.cb_wangkou.DataSource = SerialPort.GetPortNames();
            //获取波特率列表
            this.cb_baundrate.DataSource = new string[] { "9600","19200","57600","115200"};
            ********/
            /*****串口波特率
            this.cb_baundrate.DataSource = Enum.GetNames(typeof(Parity));
            ******/

            /*****
            string[] PortName = SerialPort.GetPortNames();
            Array.Sort(PortName);//给端口名称排序
            for (int i = 0; i < PortName.Length; i++)
            {
                cb_wangkou.Items.Add(PortName[i]);//给comboBox1添加选项
            }
            if (PortName.Length < 1)
            {
                cb_wangkou.Items.Add("无可连接的串口");
                cb_baundrate.Items.Add("无可选择波特率的串口");
            }
            else
            {
                cb_baundrate.Items.Add("9600");
                cb_baundrate.Items.Add("115200");
            }
            ******/

            //this.timer.Interval = 500;
            //this.timer.Tick += Timer_Tick;
        }
        #endregion


        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("您是否要退出程序？", "提示", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;    //执行新线程时跨线程资源访问检查会提示报错，所以这里关闭检测
            string[] str = SerialPort.GetPortNames();
            foreach (string port in str)
            {
                cb_port.Items.Add(port);
            }
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(port_DataReceived);
        }

        #region 串口功能

        //打开串口
        private void btn_openusb_Click(object sender, EventArgs e)
        {
            try
            {
                //将端口号和波特率赋值给串口
                serialPort1.PortName = cb_port.Text;  //标准格式为 <COM数字>
                //comboBox2.Text是字符串，将它作为十进制数转换为int32类型
                //serialPort1.BaudRate = Convert.ToInt32(cb_baudrate.Text, 10);
                //打开串口
                serialPort1.Open();
                //一旦打开端口，就将打开端口置为不可用（不能重复打开），将关闭端口置为可用
                btn_openusb.Enabled = false;  //打开端口button不可用
                btn_closeusb.Enabled = true;   //关闭端口button可用
            }
            //如果try中的语句遇到错误，则直接跳去执行catch中的语句
            catch
            {
                serialPort1.Close();
                MessageBox.Show("端口错误，请检查串口", "错误");
                btn_openusb.Enabled = true;  //打开端口button不可用
                btn_closeusb.Enabled = false;   //关闭端口button可用
            }
        }

        //关闭串口
        private void btn_closeusb_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Close();
                btn_openusb.Enabled = true;
                btn_closeusb.Enabled = false;
            }
            catch
            {
                //一般情况下关闭串口不会出错，所以不需要加处理程序
            }
        }

        //USB发送
        private void btn_usb_send_Click(object sender, EventArgs e)
        {
            //发送数据的缓冲区
            byte[] Data = new byte[1];
            //要确保串口是打开的
            if (serialPort1.IsOpen)
            {
                //确保发送数据的textBox有内容
                if (rtb_send.Text != "")
                {
                    
                    //发送模式是数值模式：即要发送的数据是16进制数，两位十六进制数组成1byte，每次发送1byte的数据
                    //示例：要发送的数据为12B63C6，则拆分成0X12,0XB6,0X3C,0X6发送
                    
                    Data = HexStringToByteArray(rtb_send.Text);
                    serialPort1.Write(Data, 0, Data.Length);
                }
            }
        }

        //USB接收
        private void port_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            if (serialPort1.IsOpen)     //此处可能没有必要判断是否打开串口，但为了严谨性，我还是加上了  
            {
                byte[] byteRead = new byte[serialPort1.BytesToRead];    //BytesToRead:sp1接收的字符个数  
                try
                {
                    Byte[] receivedData = new Byte[serialPort1.BytesToRead];        //创建接收字节数组  
                        serialPort1.Read(receivedData, 0, receivedData.Length);         //读取数据                         
                        serialPort1.DiscardInBuffer();                                  //清空SerialPort控件的Buffer  
                        string strRcv = null;
                    rtb_textshow.Text += DateTime.Now.ToString("yy-MM-dd hh:mm:ss  ") + "接收：";   //打印发送数据的时间
                    for (int i = 0; i < receivedData.Length; i++) //窗体显示  
                        {

                        strRcv += receivedData[i].ToString("X2");  //16进制显示  
                        }
                    rtb_textshow.Text += strRcv + "\r\n";
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.Message, "出错提示");
                    //txtSend.Text = "";
                }
                
            }
            else
            {
                MessageBox.Show("请打开某个串口", "错误提示");
            }
        }
        #endregion  串口



        #region 连接服务器端
        private void btn_wangkouOPEN_Click(object sender, EventArgs e)
        {
            btn_wangkouOPEN.Enabled = false;
            //创建客户端Socket
            ClientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            rtb_textshow.Text += "正在连接......" + "\n";
            //IP和端口号转换格式
            IPAddress ServerIP = IPAddress.Parse(tb_ipaddress.Text);
            int Port = int.Parse(tb_ipport.Text);
            //IP和端口号绑定
            IPEndPoint ServerAddress = new IPEndPoint(ServerIP, Port);

            try
            {
                //客户端Socket连接服务器地址
                ClientSocket.Connect(ServerAddress);
                SFlag = 1;  //若连接成功将标志设置为1
                rtb_textshow.Text += DateTime.Now.ToString("yy-MM-dd hh:mm:ss  ") + tb_ipaddress.Text + "连接成功" + "\n";
                btn_wangkouOPEN.Enabled = false;     //禁止操作连接按钮

                //开启一个线程接收数据
                th1 = new Thread(Receive);
                th1.IsBackground = true;
                th1.Start(ClientSocket);
            }
            catch
            {
                MessageBox.Show("服务器未打开");
                btn_wangkouOPEN.Enabled = true;
            }

            #region
            /*****
            serverIP = IPAddress.Parse(tb_ipaddress.Text);
            try
            {
                serverFullAddr = new IPEndPoint(serverIP, int.Parse(tb_ipport.Text));//设置IP，端口
                ClientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                //指定本地主机地址和端口号
                ClientSocket.Connect(serverFullAddr);
                //btnConn.Enabled = false;
                //rtb_textshow.Text = "连接服务器成功。。。。";
                MessageBox.Show("连接服务器成功！");
                btn_wangkouCLOSE.Enabled = true;
                //sock.Close();

            }
            catch (Exception ee)
            {
                btn_wangkouOPEN.Enabled = true;
                btn_wangkouCLOSE.Enabled = false;
                MessageBox.Show("连接服务器失败！");
                rtb_textshow.Text = "连接服务器失败。。。请仔细检查服务器是否开启" + ee;
                return;
            }
            ******/
            #endregion
        }
        #endregion

        #region 断开网络连接
        private void btn_wangkouCLOSE_Click(object sender, EventArgs e)
        {
            //保证是在连接状态下退出
            if (SFlag == 1)
            {
                byte[] send = new byte[1024];
                send = Encoding.ASCII.GetBytes("*close*");  //关闭客户端时给服务器发送一个退出标志
                ClientSocket.Send(send);

                th1.Abort();    //关闭线程
                ClientSocket.Close();   //关闭套接字

                btn_wangkouOPEN.Enabled = true;  //允许操作按钮
                SFlag = 0;  //客户端退出后将连接成功标志程序设置为0
                rtb_textshow.Text += DateTime.Now.ToString("yy-MM-dd hh:mm:ss  ");
                rtb_textshow.Text += "客户端已关闭" + "\n";
                MessageBox.Show("已关闭连接");
            }

        }
        #endregion



        #region  温度转换

        /******ADC转电阻值******/
        /******************************************
       Int16 GET_NTC_L()                   
       {
           Int16 m;
           float Rt1, Rt2;
           m = (short)(receive[0] * 256 + receive[1]);
           if (m < 4000)
           {
               Rt1 = m;
               Rt2 = (4096 - m);
               Rt2 = (Rt1 / Rt2) * 4700;  //计算此时热敏电阻阻值 		
               NTC_L = (short)Rt2;
               return NTC_L;
           }
           else
               return 4096;    //错误,返回4096,调用的程序判断 	
       }
       ********************************************/
        /*******电阻值转温度值*******/
        /******************************************
        double Get_Temp_L()
        {
            short Rt;
            double temp;
            Rt = GET_NTC_L(); //like this R=5000, T2=273.15+25,B=3470, RT=5000*EXP(3470*(1/T1-1/(273.15+25)),  
            temp = Rt / Rp;
            temp = Math.Log(temp);//ln(Rt/Rp)
            temp /= Bx;//ln(Rt/Rp)/B 
            temp += (1 / Tt);
            temp = 1 / (temp);
            temp = temp - Ka;
            temp = (int)temp + 3;
            return temp;
        }
        ********************************************/
        #endregion



        /*****************************************************************/
        #region 接收服务器端数据
        void Receive(Object sk)
        {
            Socket socketRec = sk as Socket;

            while (true)
            {
                //5.接收数据
                //byte[] receive = new byte[4];                 //receive是十进制字节数组
                ClientSocket.Receive(receive);  //调用Receive()接收字节数据
                left_temp = receive[0];
                right_temp = receive[1];


                //6.打印接收数据
                if (receive.Length > 0)
                {
                    rtb_textshow.Text += DateTime.Now.ToString("yy-MM-dd hh:mm:ss  ") + "接收：";   //打印接收时间
                    //rtb_textshow.Text += byteToHexStr(receive) + "\r\n";  //将字节数据根据ASCII码转成字符串   //字符显示Encoding.ASCII.GetString(receive)        //16进制显示byteToHexStr(receive)
                    //rtb_textshow.Text += rtb_send.Text + "\r\n";                                                                                  //rtb_textshow.Text += BitConverter.ToInt32(receive,0) + "\r\n";
                    rtb_textshow.Text += "左边温度：" + left_temp + "\r\n";                       //已经是十进制了
                    rtb_textshow.Text += "右边温度：" + right_temp + "\r\n";    

                    //测试receive[0]数据类型
                    //rtb_textshow.Text += Convert.ToString(left_temp_high).GetType();                //system.string
                    //rtb_textshow.Text += receive[0];//.GetType();                                //receive[0] = 12 (ASCII码值）     //system.byte
                }
            }
        }
        #endregion
        /*****************************************************************/

        void Send()
        {
            if (SFlag == 1)
            {
                byte[] send = new byte[1024];
                send = HexStringToByteArray(rtb_send.Text);
                //send = Encoding.ASCII.GetBytes(rtb_send.Text);  //将文本内容转换成字节发送
                ClientSocket.Send(send);    //调用Send()函数发送数据

                rtb_textshow.Text += DateTime.Now.ToString("yy-MM-dd hh:mm:ss  ") + "发送：";   //打印发送数据的时间
                rtb_textshow.Text += rtb_send.Text + "\n";   //打印发送的数据  rtb_send.Text + "\n"; 
                //rtb_send.Clear();   //清空发送框
            }
        }
        //将十六进制字符串专场byte数组
        public static byte[] HexStringToByteArray(string s)
        {
            s = s.Replace(" ", "");
            byte[] buffer = new byte[s.Length / 2];
            for (int i = 0; i < s.Length; i += 2)
                buffer[i / 2] = (byte)Convert.ToByte(s.Substring(i, 2), 16);
            return buffer;
        }

        //字节数组转16进制字符串   
        public static string byteToHexStr(byte[] bytes)
        {
            string returnStr = "";
            if (bytes != null)
            {
                for (int i = 0; i < bytes.Length; i++)
                {
                    //为C#中的字符串格式控制符
                    returnStr += bytes[i].ToString("X2") + ' ';//ToString("X2")
                }
            }
            return returnStr;
        }


        /*****************************************************************/
        #region 向服务器端发送数据
        private void btn_send_Click(object sender, EventArgs e)
            {
                if (SFlag == 1)
                {
                    byte[] send = new byte[1024];
                    send = HexStringToByteArray(rtb_send.Text);
                    //send = Encoding.ASCII.GetBytes(rtb_send.Text);  //将文本内容转换成字节发送
                    ClientSocket.Send(send);    //调用Send()函数发送数据

                    rtb_textshow.Text += DateTime.Now.ToString("yy-MM-dd hh:mm:ss  ") + "发送：";   //打印发送数据的时间
                    rtb_textshow.Text += rtb_send.Text + "\n";   //打印发送的数据  rtb_send.Text + "\n"; 
                    rtb_send.Clear();   //清空发送框
                }
            }
        #endregion
        /*****************************************************************/

        private void btn_clear_Click(object sender, EventArgs e)
        {
            //清空消息
            rtb_textshow.Text = "";
        }



        #region  左控制
        //左光能量+
        private void btn_left_pwmup_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 01 10 00 ff";
            this.btn_left_pwmup.Click += new System.EventHandler(btn_send_Click);
        }
        //左光能量-
        private void btn_left_pwmdown_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 01 11 00 ff";
            this.btn_left_pwmdown.Click += new System.EventHandler(btn_send_Click);
        }


        //左电机上升
        private void btn_left_motorup_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 01 12 00 ff";
            Send();
            //this.btn_left_motorup.Click += new System.EventHandler(btn_send_Click);
        }
        //左电机下降
        private void btn_left_motordown_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 01 13 00 ff";
            Send(); 
            //this.btn_left_motordown.Click += new System.EventHandler(btn_send_Click);
        }
        private void gb_left_motor_Enter(object sender, EventArgs e)
        {
            
        }

        //左光温度显示
        private void rb_left_tempOPEN_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            left_temp_flag = 1;
        }
        //左光温度隐藏
        private void rb_left_tempCLOSE_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            left_temp_flag = 0;
        }

        //rtb_send.Text = "fe 01 14 00 ff";
        //Send();
        //左时间+

        /**********文本框模式下：输入内容转换成字节数组
           string s;
           byte[] num;
           rtb_send.Text = "fe 01 14 00 ff";      //"fe 01 14 0xXX(时间）ff"
           if (tb_left_redtime.Text != "")
           {
               s = rtb_send.Text;
               num = HexStringToByteArray(s);
               num[3] = (byte)Convert.ToByte(tb_left_redtime.Text);
               rtb_send.Text = byteToHexStr(num);
           }
           ********************/

        //左红光选择
        private void rb_left_red_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 01 16 00 ff";
            Send();
            //this.rb_left_red.CheckedChanged += new System.EventHandler(btn_send_Click);
        }
        //左蓝光选择
        private void rb_left_blue_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 01 17 00 ff";
            Send();
            //this.rb_left_blue.CheckedChanged += new System.EventHandler(btn_send_Click);
        }

        //左启动
        private void rb_left_start_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 01 18 00 ff";
            Send();
        }
        //左停止
        private void rb_left_stop_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 01 19 00 ff";
            Send();
            //this.rb_left_stop.CheckedChanged += new System.EventHandler(btn_send_Click);
        }
        #endregion

        #region 右控制
        //右红光选择
        private void rb_right_red_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 02 16 00 ff";
            Send();
            //this.rb_right_red.Click += new System.EventHandler(btn_send_Click);
        }
        //右蓝光选择
        private void rb_right_blue_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 02 17 00 ff";
            Send();
            //this.rb_right_blue.Click += new System.EventHandler(btn_send_Click);
        }

        //右启动
        private void rb_right_start_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 02 18 00 ff";
            Send();
            //this.rb_right_start.Click += new System.EventHandler(btn_send_Click);
        }
        //右停止
        private void rb_right_stop_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 02 19 00 ff";
            Send();
            this.rb_right_stop.Click += new System.EventHandler(btn_send_Click);
        }

        //右光能量+
        private void btn_right_pwmup_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 02 10 00 ff";
            this.btn_right_pwmup.Click += new System.EventHandler(btn_send_Click);
        }
        //右光能量-
        private void btn_right_pwmdown_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 02 11 00 ff";
            this.btn_right_pwmdown.Click += new System.EventHandler(btn_send_Click);
        }

        //右电机上升
        private void btn_right_motorup_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 02 12 00 ff";
            this.btn_right_motorup.Click += new System.EventHandler(btn_send_Click);
        }
        //右电机下降
        private void btn_right_motordown_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 02 13 00 ff";
            this.btn_right_motordown.Click += new System.EventHandler(btn_send_Click);
        }

        //右光显示温度
        private void rb_right_tempOPEN_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            right_temp_flag = 1;
        }
        //右光隐藏温度
        private void rb_right_tempCLOSE_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            right_temp_flag = 0;
        }

        #endregion


        //定时显示温度
        private void timer1_Tick(object sender, EventArgs e)
        {
            Series left_series = cht_temp.Series[0];
            Series right_series = cht_temp.Series[1];
            //cht_temp.ChartAreas[0].AxisX.ScaleView.Position = left_series.Points.Count - 10;//让进度条跟着数据源往前走
            //cht_temp.ChartAreas[0].AxisX.ScaleView.Position = right_series.Points.Count - 10;

            if (left_temp_flag == 1)
            {
                left_series.Points.AddY(left_temp);// ra.Next(1, 50) 
                cht_temp.ChartAreas[0].AxisX.ScaleView.Position = left_series.Points.Count - 10;//让进度条跟着数据源往前走
            }
            
            if (right_temp_flag == 1)
            {
                right_series.Points.AddY(right_temp);
                cht_temp.ChartAreas[0].AxisX.ScaleView.Position = right_series.Points.Count - 10;
            }


            //cht_temp.ChartAreas[0].AxisX.ScaleView.Position = left_series.Points.Count - 10;//让进度条跟着数据源往前走
            //cht_temp.ChartAreas[0].AxisX.ScaleView.Position = right_series.Points.Count - 10;

            //this.cht_temp.Series[0].Points.AddY(left_temp);             //byteToHexStr(receive)
            //this.cht_temp.Series[1].Points.AddY(right_temp);

            #region  listview显示
            
            this.lv_temp.BeginUpdate();   //数据更新，UI暂时挂起，直到EndUpdate绘制控件，可以有效避免闪烁并大大提高加载速度

            this.lv_temp.Items.Clear();  //只移除所有的项。
            for (int i = 0; i < 2; i++)   //添加2行数据
            {
                ListViewItem lvi = new ListViewItem();

                //lvi.ImageIndex = i;     //通过与imageList绑定，显示imageList中第i项图标
                if (i == 0)
                {
                    lvi.Text = "左光";

                    lvi.SubItems.Add("温度为：" + left_temp);

                    lvi.SubItems.Add("采样时间为" + DateTime.Now);
                }
                else if (i == 1)
                {
                    lvi.Text = "右光";

                    lvi.SubItems.Add("温度为：" + right_temp);

                    lvi.SubItems.Add("采样时间为" + DateTime.Now);
                }
                this.lv_temp.Items.Add(lvi);
            }

            this.lv_temp.EndUpdate();  //结束数据处理，UI界面一次性绘制。

            #endregion
        }


        #region  chart初始化
        //chart初始化，作参考，本实验不用
        private void Init_Chart()
        {
     
            #region x轴缩放
            //防止数据点重叠
            cht_temp.Series[0].SmartLabelStyle.Enabled = true;
            cht_temp.Series[1].SmartLabelStyle.Enabled = true;
            //超过图表界是否发生滚动
            cht_temp.ChartAreas["ChartArea1"].CursorX.AutoScroll = true;
            //是否启用滚动条
            cht_temp.ChartAreas["ChartArea1"].AxisX.ScrollBar.Enabled = true;
            //启用光标用户界面
            cht_temp.ChartAreas["ChartArea1"].CursorX.IsUserEnabled = true;
            //启用用户选择范围--不用选择范围进行放大
            cht_temp.ChartAreas["ChartArea1"].CursorX.IsUserSelectionEnabled = true;
            //启用缩放
            cht_temp.ChartAreas["ChartArea1"].AxisX.ScaleView.Zoomable = true;

            //设置从哪个点（idx）开始显示
            cht_temp.ChartAreas["ChartArea1"].AxisX.ScaleView.Position = dataCounts - 10;    //chartShowPointCount;
            //设置图表可视区域数据点数，即一次可以看到多少个X轴区域
            cht_temp.ChartAreas["ChartArea1"].AxisX.ScaleView.Size = 10;    // chartShowPointCount;



            cht_temp.ChartAreas[0].AxisX.ScrollBar.IsPositionedInside = true;
            cht_temp.ChartAreas[0].AxisX.ScrollBar.Enabled = true;
            #endregion



            /*********
            UpdateQueueValue();
            dataQueue.Enqueue(left_temp);
            dataQueue1.Enqueue(right_temp);
            for (int i = 0; i < dataQueue.Count; i++)
            {
                this.cht_temp.Series[0].Points.AddXY((i + 1), dataQueue.ElementAt(i));
            }
            for (int i = 0; i < dataQueue1.Count; i++)
            {
                this.cht_temp.Series[1].Points.AddXY((i + 1), dataQueue1.ElementAt(i));
            }
            *******/

        }
        #endregion

        //左时间+
        private void btn_left_timeup_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 01 14 00 ff";
            Send();
        }
        //左时间-
        private void btn_left_timedown_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 01 15 00 ff";
            Send();
        }
        //右时间+
        private void btn_right_timeup_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 02 14 00 ff";
            Send();
        }
        //右时间-
        private void btn_right_timedown_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 02 15 00 ff";
            Send();
        }

        #region 组合模式
        //左红光时间+
        private void btn_left_red_timeup_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 10 00 ff";
            Send();
        }
        //左红光时间-
        private void btn_left_red_timedown_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 11 00 ff";
            Send();
        }
        //左蓝光时间+
        private void btn_left_blue_timeup_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 12 00 ff";
            Send();
        }
        //左蓝光时间-
        private void btn_left_blue_timedown_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 13 00 ff";
            Send();
        }
        //右红光时间+
        private void btn_right_red_timeup_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 14 00 ff";
            Send();
        }
        //右红光时间-
        private void btn_right_red_timedown_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 15 00 ff";
            Send();
        }
        //右蓝光时间+
        private void btn_right_blue_timeup_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 16 00 ff";
            Send();
        }
        //右蓝光时间-
        private void btn_right_blue_timedown_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 17 00 ff";
            Send();
        }
        #endregion

        //单/双模式切换
        //单模式
        private void rb_single_mode_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 01 01 ff";
            Send();
        }
        //双模式
        private void rb_double_mode_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 01 02 ff";
            Send();
        }
        //左频闪
        private void rb_left_pinshan_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 02 01 ff";
            Send();
        }
        //左连续
        private void rb_left_lianxu_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 02 02 ff";
            Send();
        }
        //右频闪
        private void rb_right_pinshan_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 03 01 ff";
            Send();
        }
        //右连续
        private void rb_right_lianxu_Click(object sender, EventArgs e)
        {
            rtb_send.Text = "fe 03 03 02 ff";
            Send();
        }

        
    }
}



