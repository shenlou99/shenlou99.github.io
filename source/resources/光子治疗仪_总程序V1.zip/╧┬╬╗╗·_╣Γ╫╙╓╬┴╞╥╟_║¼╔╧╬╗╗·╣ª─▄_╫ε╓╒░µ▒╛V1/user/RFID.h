#ifndef	_RFID_H
#define	_RFID_H

void COM3_RFID(void);
void clean_COM3_RFID_DATA(void);
void TX3_RFID_CHAXUN( u8 cmd1, u8 add );
void TX3_RFID_KOUFEI(u8 cmd1,u8 add,u8 dat);
unsigned char CheckSum(unsigned char *ptr,unsigned char len);
void TX3_RFID_SHANGCHUAN(void);

#endif