#ifndef	__WT588D_H
#define	__WT588D_H

void Send_oneline(unsigned char addr);
void Delay200us();
void Delay600us() ;
void Delay17ms();
void Delay5ms() ;

#endif