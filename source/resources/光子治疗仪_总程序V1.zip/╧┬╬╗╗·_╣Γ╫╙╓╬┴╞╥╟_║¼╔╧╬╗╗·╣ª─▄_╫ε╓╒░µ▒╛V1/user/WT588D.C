#include	"timer.h"
#include	"WT588D.h"
#include	"head.h"

extern uchar speaker;

void Send_oneline(unsigned char addr)
 {
  unsigned char i; 
  if(speaker)
  {
	SPK_RST = 0;
	Delay5ms(); 
	SPK_RST = 1;
	Delay17ms();        /*?delay?20ms?*/ //delay_ms(5); 
	SPK_CON=0; 
	Delay5ms(); /*?delay?5ms?*/ //delay_ms(25)
for(i=0;i<8;i++) 
{  
	
if(addr & 1)
{  
	SPK_CON=1; 
	Delay600us();      /*?600us?*/ 
	SPK_CON=0; 
	Delay200us();      /*?200us?*/ 
 } 
 else
{  
	SPK_CON=1; 
	Delay200us(); /*?600us?*/ 
	SPK_CON=0; 
	Delay600us(); /*??200us?*/ 
	
} 
      addr>>=1; 
 }  
 SPK_CON=1; 	
} 
} 
void Delay5ms()		//@11.0592MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 75;
	j = 205;
	do
	{
		while (--j);
	} while (--i);
}
void Delay17ms()		//@11.0592MHz      20ms
{
	unsigned char i, j, k;

	i = 2;
	j = 32;
	k = 60;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}
void Delay600us()		//@11.0592MHz
{
	unsigned char i, j;

	_nop_();
	_nop_();
	i = 9;
	j = 155;
	do
	{
		while (--j);
	} while (--i);
}
void Delay200us()		//@11.0592MHz
{
	unsigned char i, j;

	i = 3;
	j = 221;
	do
	{
		while (--j);
	} while (--i);
}

