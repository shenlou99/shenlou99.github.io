void work_start (void)
{
	if(ZHRB==0)   //tmp[4]                         //����
	{
		if(((Second==0)&&(Minute==0))||(CR ==1))         //ʱ��Ϊ0����PCA ���ƼĴ���CR��1��
		break;			
		CR=1; 
		if(RB_LED)  //tmp[3]                         //�����ѡ��
		{	
			PWMB_Duty.PWM5_Duty = pwm_B[nlval-1];
			EN_B=1;
		}
		else if(RB_LED==0)                   //������ѡ��
		{
			PWMB_Duty.PWM5_Duty = pwm_A[nlval-1];
			EN_R=1;
		}
	}														 
	TR0=1;
	Write_EEPDATA();                     //д��eprom
	Send_oneline(0);                     //y����
}

void work_stop (void)
{
	if(CR ==0)         
	//							 break;
	CR=0;
	PWMB_Duty.PWM5_Duty =3000;  
	EN_R=0;
	EN_B=0; 	
	TR0=0; 						
	tx2_lcd_B(1);                            	//��ʾ��������
	Send_oneline(1);                         	//y����
	T_Flag=1;                                	//ֹͣ��־λ����ʾ�趨ʱ��
	TRB_Flag=1;
	
}

void work_time_up (void)
{
	if(EN_R==0&EN_B==0)				  
	{	switch(COM2_LCD_DATA[8])	  
		{	case 0X01:                               	//MINSʱ���
			{
			set_Minute=Minute;set_Minute+=5; if(set_Minute>60) set_Minute=1;					
			Minute=set_Minute;Second=0; 
			Send_oneline(9);
			tx2_lcd_T(0x08,((Minute/10)<<4)+(Minute%10));										///////////////�ķֵ�ַ0x04-8
			tx2_lcd_T(0x02,((Second/10)<<4)+(Second%10));
			//tx2_lcd2 (((Minute/10)<<4)+(Minute%10));														 //�����趨ֵ

			}
			COM2_LCD_DATA[0]=0x00;	 break; 													
			case 0X02:                              	//MINSʱ���
			{ 
			set_Minute=Minute;set_Minute-=5; if(set_Minute>60|set_Minute==0)set_Minute=60;					 //ʱ���
			Minute=set_Minute; Second=0;	
			Send_oneline(8);
			tx2_lcd_T(0x08,((Minute/10)<<4)+(Minute%10));											 ///////////////�ķֵ�ַ0x04-8
			tx2_lcd_T(0x02,((Second/10)<<4)+(Second%10)); 
			//tx2_lcd2 (((Minute/10)<<4)+(Minute%10));   //�����趨ֵ

			}
			COM2_LCD_DATA[0]=0x00;	 break; 												 
			default:break;
		}
	}
}

work_time_down (void)
{
	if(EN_R==0&EN_B==0)				  
	{switch(COM2_LCD_DATA[8])	  
		{case 0X01:                                 //SECSʱ���
			{
				set_Minute=Minute;set_Minute++; if(set_Minute>60)set_Minute=1;					
				Minute=set_Minute;Second=0; 
				Send_oneline(9);
				tx2_lcd_T(0x08,((Minute/10)<<4)+(Minute%10));													///////////////�ķֵ�ַ0x04-8
				tx2_lcd_T(0x02,((Second/10)<<4)+(Second%10));	
				//tx2_lcd2 (((Minute/10)<<4)+(Minute%10));														 //�����趨ֵ
			}
			COM2_LCD_DATA[0]=0x00;	 break; 													
			case 0X02:                                 //SECSʱ���
			{ 
				set_Minute=Minute;set_Minute--; if(set_Minute>60|set_Minute==0)set_Minute=60;					 
				Minute=set_Minute; Second=0; 
				Send_oneline(8);
				tx2_lcd_T(0x08,((Minute/10)<<4)+(Minute%10));													 ///////////////�ķֵ�ַ0x04-8
				tx2_lcd_T(0x02,((Second/10)<<4)+(Second%10)); 
				//tx2_lcd2 (((Minute/10)<<4)+(Minute%10));                               //�����趨ֵ
			}
			COM2_LCD_DATA[0]=0x00;	 break; 												 
			default:break;
		}
	}
}