#ifndef __K600_H
#define __K600_H	 

#include	"config.h"
#include 	"STC8xxxx.H"  

#define uchar unsigned char
#define uint 	unsigned int
	




void tx2_lcd_T(uchar add1 ,uchar dat1);
void tx2_lcd(uchar add2 ,uchar dat2);
void tx2_lcd_P(uchar dat3);
void tx2_lcd_B( uchar add4 ,uchar dat4   );
void tx1_lcd_P();
void tx1_EEPROM();
void COM2_LCD(void);
void CLEAN_COM2_LCD_DATA(void);



#endif