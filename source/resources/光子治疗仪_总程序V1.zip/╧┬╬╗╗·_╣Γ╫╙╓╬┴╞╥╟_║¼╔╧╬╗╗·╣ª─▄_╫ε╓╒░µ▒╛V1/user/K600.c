#include 	"STC8xxxx.H"   
#include	"GPIO.h"
#include	"UART.h"
#include	"K600.h"
#include	"head.h"

	
u8 COM2_LCD_DATA[22];	


/*******���ݴ���**********/
/**************lcd�����ʽ-----������������Ƭ��******************
		������	5A A5 06 83 00 00 01 00 01 
		ֹͣ��	5A A5 06 83 00 00 01 00 02
		������	5A A5 06 83 00 06 01 00 01 
		�½���	5A A5 06 83 00 06 01 00 02
		min+��  5A A5 06 83 00 05 01 00 01
		min-��  5A A5 06 83 00 05 01 00 02
		sec+��  5A A5 06 83 00 09 01 00 01
		sec-��  5A A5 06 83 00 09 01 00 02 
		����+��	5A A5 06 83 00 07 01 00 06
		����-��	5A A5 06 83 00 07 01 00 01
		���⣺	5A A5 06 83 00 0A 01 00 00 
		��⣺
		˫�� 		5A A5 06 83 00 23 01 00 01 
		����
		���Σ�	5A A5 06 83 00 04 01 00 01
		������	5A A5 06 83 00 0B 01 00 01
		***************************************/
//���COM2���յ����ݣ����� COM2_LCD_DATA[]����	
void COM2_LCD(void)		
{
	u8 i=0;   
	
	if((RX2_Buffer[0]==0x5A)&&(RX2_Buffer[1]==0xA5)&&(RX2_Buffer[3]==0x83) )
	{
		for(i=0;i<9;i++)	
		{ 
			COM2_LCD_DATA[i]	=		RX2_Buffer[i];						
		}	
//		tx1_lcd_P();
	} 
	RX2_Buffer[0] = 0;
	
}	
void CLEAN_COM2_LCD_DATA(void)
{
	u8 i = 0;
	
	for(i=0;i<9;i++)
	{
	 	COM2_LCD_DATA[i] = 0;
		RX2_Buffer[i]=0;
	}
}
void tx2_lcd( uchar add2 ,uchar dat2 )
	{
		TX2_write2buff(0x5a);
		TX2_write2buff(0xa5);
		TX2_write2buff(0x05);
		TX2_write2buff(0x82);
		TX2_write2buff(0x10);
		TX2_write2buff(add2);
		TX2_write2buff(0x00);	
		TX2_write2buff(dat2);
	}
	
void tx2_lcd_T( uchar add1 ,uchar dat1 )									//ʱ��
	{
		TX2_write2buff(0x5a);
		TX2_write2buff(0xa5);
		TX2_write2buff(0x05);
		TX2_write2buff(0x82);
		TX2_write2buff(0x10);
		TX2_write2buff(add1);
		TX2_write2buff(dat1);
		TX2_write2buff(0x00);	
	}
void tx2_lcd_B( uchar add4 ,uchar dat4   )                //��ʾ��ð�� ��
	{
		TX2_write2buff(0x5a);
		TX2_write2buff(0xa5);
		TX2_write2buff(0x04);
		TX2_write2buff(0x82);
		TX2_write2buff(0x10);
		TX2_write2buff(add4);
		//TX2_write2buff(' ');          //�ո�0x20
		
		if(dat4 ==1)
			TX2_write2buff(0x3a);        //ð��0x3a
		else	
			TX2_write2buff(0x20);				//��ֵ��λ*/
	}
void tx2_lcd_P( uchar dat3   )               //�л�ҳ��ָ��5A A5 07 82 0084 5A01 0001
	{
		TX2_write2buff(0x5a);
		TX2_write2buff(0xa5);
		TX2_write2buff(0x07);
		TX2_write2buff(0x82);
		TX2_write2buff(0x00);
		TX2_write2buff(0x84);
		TX2_write2buff(0x5a);
		TX2_write2buff(0x01);
		TX2_write2buff(0x00);
		TX2_write2buff(dat3);
		}
//	
void tx1_lcd_P()
{   
	u8 i;		
	for(i=0;i<9;i++)
	{	
//		TX1_write2buff(RX3_Buffer[i]);
//		TX1_write2buff(COM3_RFID_DATA[i]);
		TX1_write2buff(RX2_Buffer[i]);
	}   
}		  
//void tx1_EEPROM()
//{   
////	u8 i;
//	
////	for(i=0;i<6;i++)
////	{
////		
////		TX1_write2buff(tmp[i]);
////		}
//		TX1_write2buff(Minute);
//		TX1_write2buff(R_Minute);
//		TX1_write2buff(B_Minute);
//		TX1_write2buff(RB_LED);
//		TX1_write2buff(ZHRB);
//		TX1_write2buff(ZHRB_LED);
//}		




