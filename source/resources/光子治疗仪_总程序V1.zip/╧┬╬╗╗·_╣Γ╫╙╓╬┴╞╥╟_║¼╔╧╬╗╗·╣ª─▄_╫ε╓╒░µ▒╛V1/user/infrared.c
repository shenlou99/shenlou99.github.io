#include <STC12C5A60S2>  //��������Լ���51��Ƭ��оƬ���޸ġ�

sbit INIR = P3^2;   //��������Լ��������š�
bit InFrared_Way = 0;
unsigned char Data[4] = {0};

void InFrared_Init(void);

void main(void)
{
 TMOD = 0x01;
 TR0 = 0;
 IT0 = 1;
 EX0 = 1;
 EA = 1;
 while (1)
 {
  if (InFrared_Way == 1)
  {
   EX0 = 0;
   TR0 = 1;
   InFrared_Init();
   TR0 = 1;
   EX0 = 1;
   InFrared_Way = 0;
  }
 }
}

void Int_0(void) interrupt 0
{
 InFrared_Way  = 1;
}

void InFrared_Init(void)
{
 unsigned char i, j;
 
 TH0 = 0;
 TL0 = 0;
 while (INIR == 0 && TH0 <= 35);
 if (INIR == 1)
 {
  while (INIR == 1 && TH0 <= 55);
  for (i = 0; i < 4; i++)
  {
   for (j = 0; j < 8; j++)
   {
    TH0 = 0;
    TL0 = 0;
    while (INIR == 0 && TH0 <= 3);
    while (INIR == 1);
    Data[i] >>= 1;
    if (TH0 >= 7)
    {
     Data[i] |= 0x80;
    }
   }
  }
 }
}