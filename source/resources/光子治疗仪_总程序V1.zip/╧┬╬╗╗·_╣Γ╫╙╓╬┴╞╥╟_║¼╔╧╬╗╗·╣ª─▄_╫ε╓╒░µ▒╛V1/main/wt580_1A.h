
bit yuyin=1;

void delay1ms(unsigned  char count) //1MS?��ʱ�ӳ���??
{ 
  unsigned char i,j,k; 
  for(k=count;k>0;k--) 
     for(i=2;i>0;i--) 
       for(j=248;j>0;j--); 
} 
void delay100us(unsigned char count)    //100US?��ʱ����?
 {    
  unsigned char i; 
 unsigned char j; 
 for(i=count;i>0;i--) 
 for(j=50;j>0;j--); 
 } 
 
  
 void Send_oneline(unsigned char addr)
 {
  unsigned char i; 
  if(yuyin)
  {
 delay1ms(17);        /*?delay?20ms?*/ //delay1ms(5); 
 SPK_CON=0; 

 delay1ms(5); /*?delay?5ms?*/ //delay1ms(25)
for(i=0;i<8;i++) 
{
if(addr & 1)
{
 SPK_CON=1;  
 delay100us(6);      /*?600us?*/ 
 SPK_CON=0; 
 delay100us(2);      /*?200us?*/ 
 } 
 else
{  
 SPK_CON=1; 
 delay100us(2); /*??200us?*/ 
 SPK_CON=0; 
 delay100us(6); /*?600us?*/ 
} 
      addr>>=1; 
 }  
 SPK_CON=1; 
 }
} 
 
