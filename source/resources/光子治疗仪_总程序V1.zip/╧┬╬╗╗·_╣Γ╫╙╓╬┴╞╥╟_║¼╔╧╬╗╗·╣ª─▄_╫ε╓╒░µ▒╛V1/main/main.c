#include 	"STC8xxxx.H"   
#include	"GPIO.h"
#include	"UART.h"
#include	"delay.h"
#include 	"eeprom.h"
#include	"timer.h"		
#include	"PWM.h"	
#include	"WT588D.h"	
#include	"ADC.h"
#include	"head.h"
#include	"Exti.h"
#include	"RFID.h"
#include	"K600.h"
/*************	���س�������	**************/
uchar 	t500ms,t50ms=20,t50ms2=20;  
uchar		Timer4_flag=0;

uchar 	speaker = 1 ;


uchar		Set_Minute=0;															//���õ���ʱ��
uchar  	set_R_Minute=0,set_B_Minute=0,set_RB_Minute=0;//�������ģʽ������ʱ��
uchar 	Second=0,Minute=0;         									//����ģʽ������ʾ
uchar  	R_Minute=0,R_Second=0,B_Minute=0,B_Second=0,RB_Minute=0,RB_Second=0;       //���ģʽ������ʾ
uchar		S_Flag=1;        		//ð����ʾ��־
uchar		Stop_flag=0,Time_Stop_flag=0;     //ֹͣ��־
uchar		Run_Flag=0;   //������־ 
uchar 	ZHRB=1;       //�������ѡ��							//1������   2�����ģʽ
uchar 	RB_LED=0;     //���졢����ѡ��						//0�����     1������
uchar 	ZHRB_LED=0;   //��Ϻ졢������ѡ��				//0�����     1������


uchar		S_Flag2=1; 
uchar		Stop_flag2=0,Time_Stop_flag2=0;     //ֹͣ��־
uchar		Run_Flag2=0;   //������־ 
uchar 	ZHRB2=1;       //�������ѡ��
uchar 	RB_LED_L=0;     //���졢����ѡ��
uchar 	ZHRB_LED_L=0;   //��Ϻ졢������ѡ��
uchar		Set_Minute2=0;															//���õ���ʱ��
uchar  	set_R_Minute2=0,Set_B_Minute2=0,set_RB_Minute2=0;//�������ģʽ������ʱ��
uchar 	Second2=0,Minute2=0;         									//����ģʽ������ʾ
uchar  	R_Minute2=0,R_Second2=0,B_Minute2=0,B_Second2=0,RB_Minute2=0,RB_Second2=0;       //���ģʽ������ʾ
uchar   Page_Flag=1;  //��һҳ��־

u16 nlval=1,nlval2=1,C50ms=20, C10ms=20,Hzval=0,Hzval2=0;
uchar Time_RB_Stop_flag,Time_RB_Stop_flag2,Time_50ms_flag=1,Time_50ms_flag2=1;
uchar IR_Flag=0;


unsigned char tmp[100]={0};                    	// eeprom���ݴ洢
unsigned char dat[4] = {0};  					 					// ���ڴ�ź��ⰴ����ֵ����ʼ��Ϊ0000 0000������������ʱ����ֻ����1��

u16 pwm_A[6] = {700,600,500,400,300,200};   //	100W���
u16 pwm_B[6] = {700,600,500,400,300,200}; 	 //	100W����

u8 left_pwm_A_num = 0,left_pwm_B_num = 0;
u8 right_pwm_A_num = 0,right_pwm_B_num = 0;
u8 lr_temp[2];													//�����¶�ֵ��������
//u8 Left_Temp[150] = {0};							//���¶�ֵ
//u8 left_temp_flag = 0;									//���¶�ֵ׼����־
////////////////////ң���źű�־λ//////////////

//////////////////////////////////////////////////

/*************	���ر�������	**************/



/*************  �ⲿ�����ͱ��������¶ȴ��������� *****************/
extern   PWMx_Duty PWMB_Duty;



extern u8 COM2_LCD_DATA[22];				//���մ���2������������������
extern u8 COM3_RFID_DATA[22] ;				//���մ���3��RFID����������
extern u8 koufei_flag ;						//�۷ѱ�־
extern u8 RFID_SHANGCHUAN_FLAG;				//RFID�ϴ���־


/*************	���غ�������	**************/
void STOP_APP(u8 LEFT_OR_RIGHT) ;						//6��APPֹͣģʽ
void RUN_APP(u8 LEFT_OR_RIGHT) ;						//2��APP����ģʽ	
void UP_DOWN_APP(u8 LEFT_OR_RIGHT,u8 UP_OR_DOWN);		//���APP
void MIN_APP(u8 LEFT_OR_RIGHT);							//ʱ��APP
void cmd_feedback(void);										//��λ�������
//void Send_Left_Temp(void);								//��ȡ���¶�ֵͨ������4����
void Send_Temp(void);											//�����������¶�ֵ
/***********************************************/
void main(void)
{

// *************�ⲿ��������**********//
	P_SW2 = 0x80;
	XOSCCR = 0xEC;//0xc0;                       //�����ⲿ����
	while (!(XOSCCR & 1));                      //�ȴ�ʱ���ȶ�
	CLKDIV = 0x00;                              //ʱ�Ӳ���Ƶ
	CLKSEL = 0x01;                              //ѡ���ⲿ����
	MCLKOCR = 0x84;
	P_SW2 = 0x00;
//**************************************//

//***********ϵͳ��ʼ��***************************//
	GPIO_config();
	Timer_config();
	UART_config();	
	PWM_config();
	ADC_config();
	Exti_config(); 	
	
	EA = 1;         // CPU׼���ж�
	
	moto_en  	= 0;
	moto_up 	= 0;
	moto_down	=	0;
	
	moto_en2  	= 0;
	moto_up2 	= 0;
	moto_down2	=	0;
	
	FAN_LED =1;	
	FAN_LED2 = 1;
	
	EN_R	= 0;
	EN_B	= 0;
	EN_Y  = 0;
	EN_G  = 0;
	
	EN_R2	= 0;
	EN_B2	= 0;
	EN_Y2  = 0;
	EN_G2  = 0;
	BELL=0;
	Timer0_Stop()	;
	Timer4_Stop()	;
	delay_ms(200);  

	PWMB_Duty.PWM5_Duty =0;  //�������ָߵ�ƽ
	PWMB_Duty.PWM8_Duty =0;  //�������ָߵ�ƽ 	
	
	ZHRB=1;
	ZHRB2=1;
	speaker=1;
	delay_ms(200); 
	delay_ms(200); 
	delay_ms(200); 
	delay_ms(200); 
	delay_ms(200); 
	delay_ms(200); 
	delay_ms(200); 
	delay_ms(200); 
	tx2_lcd_P(11);
	

	while(1) /*����ѭ��*/
	{

/*******************��ȡ��λ�������**************/
//		cmd_feedback();
//		UpdatePwm(PWMB, &PWMB_Duty); 
		/***************ͬ���ϴ��¶�ֵ����λ��*************/
//			if((Run_Flag == 1) | (Run_Flag2 == 1))
//			{
//				Send_Temp();
//				delay_ms(500);
//			}
		/**************��������*********************/
//			tx1_EEPROM();
//			tx1_lcd_P();
/**************��ȡ��Ƭ��Ϣ*****************/	
		TX3_RFID_SHANGCHUAN();
		if((RFID_SHANGCHUAN_FLAG ==0)	&& (Page_Flag==1))
		{ 	 
			tx2_lcd_P(11);
			Page_Flag=11;  							
		}	
		if((RFID_SHANGCHUAN_FLAG ==1) && (Page_Flag==11))
		{ 	
			tx2_lcd_P(1);
			Page_Flag=1; 
			//**********��ȡeeprom����*************//
			Read_EEPDATA();  		
			Minute         = Set_Minute;  
			R_Minute       = set_R_Minute;  
			B_Minute       = set_B_Minute;
			RB_Minute      = R_Minute + B_Minute;
			set_RB_Minute  = RB_Minute;
			Minute2         = Set_Minute2;  
			R_Minute2       = set_R_Minute2;  
			B_Minute2       = Set_B_Minute2;
			RB_Minute2      = R_Minute2 + B_Minute2;
			set_RB_Minute2  = RB_Minute2;
			delay_ms(200);  
		
		//**********LCD��ʾeeprom����*************//	
			tx2_lcd_T(0x22,((Minute/10)<<4)+(Minute%10));					//�ҷ�����ʾ
			delay_100us(100);	
			tx2_lcd(0x26,Minute);//������ֵ												//��ʱ��+/-
			delay_100us(100);
			tx2_lcd(0x45,R_Minute);//������ֵ
			delay_100us(100); 
			tx2_lcd(0x46,B_Minute);//������ֵ
			delay_100us(100); 
			tx2_lcd(0x51,RB_LED);//������ֵ	
			delay_100us(100); 
			tx2_lcd_T(0x12,((Minute2/10)<<4)+(Minute2%10));	
			delay_100us(100);	
			tx2_lcd(0x16,Minute2);//������ֵ
			delay_100us(100);
			tx2_lcd(0x35,R_Minute2);//������ֵ
			delay_100us(100); 
			tx2_lcd(0x36,B_Minute2);//������ֵ
			delay_100us(100); 
			tx2_lcd_T(0x14,0);	
			delay_100us(100); 	
			tx2_lcd_T(0x24,0);	
			delay_100us(100); 	
			delay_ms(200); 
		
	//***************��ʾ����***********//

		 if(ZHRB==2)              // ҳ��ѡ��
			{ tx2_lcd(0x51,ZHRB);
				delay_100us(100); 
				tx2_lcd_P(8);
				tx2_lcd_T(0x42,((R_Minute/10)<<4)+(R_Minute%10));
				delay_100us(100); 
				tx2_lcd_T(0x47,((B_Minute/10)<<4)+(B_Minute%10));
				delay_100us(100); 
				
				tx2_lcd_T(0x32,((R_Minute2/10)<<4)+(R_Minute2%10));
				delay_100us(100); 
				tx2_lcd_T(0x37,((B_Minute2/10)<<4)+(B_Minute2%10));
				delay_100us(100); 
			}
			
			
		}
		
		if((RFID_SHANGCHUAN_FLAG ==1))
		{ 	
/***************��ȡң���ź�*******************************/	
//		
			HongWai_Dispiay_App() ; 
			
	/***************���������PWM���***************************/	
			
			UpdatePwm(PWMB, &PWMB_Duty); 

	/***************�¶ȼ��*********************/
			TMP_C() ;	
			
/*******************��ȡ��λ�������**************/
		cmd_feedback();
		//UpdatePwm(PWMB, &PWMB_Duty); 
			
/***************ͬ���ϴ��¶�ֵ����λ��*************/
			if((Run_Flag == 1) || (Run_Flag2 == 1))
			{
				Send_Temp();
				//delay_ms(500);
			}
			
//	/***************��ȡ��Ļ��Ϣ********************************/
			COM2_LCD();     //���COM2���յ����ݣ����� COM2_LCD_DATA[]����
			if((COM2_LCD_DATA[0]==0x5A)&&(COM2_LCD_DATA[1]==0xA5)&&(COM2_LCD_DATA[2]==0x06)&&(COM2_LCD_DATA[3]==0x83)&&(COM2_LCD_DATA[4]==0x10)&&(COM2_LCD_DATA[6]==0x01)&&(COM2_LCD_DATA[7]==0x00)) 
			{  
				switch(COM2_LCD_DATA[5])
				{
					case 0x63:		 																	//��� ����ͣ
					{				  
						switch(COM2_LCD_DATA[8])	  											
						{
							case 0x01:  		//����
							{
								if((ZHRB==1) && (Minute==0))    break;     	//���� ʱ��Ϊ0
								if((ZHRB==2) && (RB_Minute==0)) break;      //��Ϲ� ʱ��Ϊ0
								RUN_APP(1);
								COM2_LCD_DATA[0]=0x00;
							}  break;
							case 0x02:       //ֹͣ
							{	
								STOP_APP(1);
								COM2_LCD_DATA[0]=0x00;
							 }  break; 											                                 
							default:break;
						}
					}break;
		//..........................//	
					case 0x64:		  															 	//�������
					{  				  
						switch(COM2_LCD_DATA[8])	  
						{
							case 0x01:   //����	
									UP_DOWN_APP(1,1) ;
									COM2_LCD_DATA[0]=0x00; break; 										 
							case 0x02:   //�½�
									UP_DOWN_APP(1,2) ;
									COM2_LCD_DATA[0]=0x00; break; 
																	 //�½�
									default:break;
						}
					} break;
		//..........................//	
					case 0x26:		  														    //���SECSʱ��Ӽ�1
					{
						MIN_APP(1);
						COM2_LCD_DATA[0]=0x00;	 break; 												
					 } break;	
		//..........................//					
					case 0x28:		  															 	//����Ƶ��			  
					{  
						if(Run_Flag==0)										 
							{ Hzval=COM2_LCD_DATA[8];
							 if(Hzval)
								Send_oneline(12);					               	//y���� ����
							 else
								 Send_oneline(13);					             	//y����  ����
							 COM2_LCD_DATA[0]=0x00; break; 
						 }
					} break;
		//..........................//	
					case 0x29:		  															 	//������ѡ��			  
					{  
						if(Run_Flag==0)										 
						{ 
							RB_LED=COM2_LCD_DATA[8];										//����ģʽ��������ѡ��
							ZHRB_LED =COM2_LCD_DATA[8];									//���ģʽ���������ȼ�
							if(RB_LED)
							Send_oneline(6);					                //����
							else
							Send_oneline(7);					                //���
							COM2_LCD_DATA[0]=0x00; break; 
						}
					} break;
		
		//..........................//					
					case 0x45:		  													      //���ģʽ-���ʱ��Ӽ�1 	
					{
						if(Run_Flag==0)				 
						 {
						 if(set_R_Minute!=COM2_LCD_DATA[8])
							{
								if(set_R_Minute<COM2_LCD_DATA[8]) Send_oneline(9);                            //����ʱ���
								else Send_oneline(8);                                               					//����ʱ���
								set_R_Minute=COM2_LCD_DATA[8];
								R_Minute=COM2_LCD_DATA[8];													                           //ʱ��� 
								R_Second=0;
								RB_Minute=R_Minute+B_Minute;
								set_RB_Minute=RB_Minute;							
								tx2_lcd_T(0x42,((R_Minute/10)<<4)+(R_Minute%10));		
								delay_100us(10);							
								tx2_lcd_T(0x44,((R_Second/10)<<4)+(R_Second%10));
								}
						 }
						else
							{if(set_R_Minute<COM2_LCD_DATA[8]) tx2_lcd(0x45,(COM2_LCD_DATA[8]-1));
							 else tx2_lcd(0x45,(COM2_LCD_DATA[8]+1));
							}	COM2_LCD_DATA[0]=0x00;	 break; 												
					 } break;			
		//..........................//							
					case 0x46:		  														    //���ģʽ-����ʱ��Ӽ�1 	
					{
						if(Run_Flag==0)			 
						 {
						 if(set_B_Minute!=COM2_LCD_DATA[8])
							{
								if(set_B_Minute<COM2_LCD_DATA[8]) Send_oneline(9);                            //����ʱ���
								else Send_oneline(8);                                              //����ʱ���
								set_B_Minute=COM2_LCD_DATA[8];
								B_Minute=COM2_LCD_DATA[8];													                           //ʱ��� 
								B_Second=0; 
								RB_Minute=R_Minute+B_Minute;
								set_RB_Minute=RB_Minute;	
								tx2_lcd_T(0x47,((B_Minute/10)<<4)+(B_Minute%10));
								delay_100us(10);
								tx2_lcd_T(0x49,((B_Second/10)<<4)+(B_Second%10));							
								
								}
						 }
						else
							{if(set_B_Minute<COM2_LCD_DATA[8]) tx2_lcd(0x46,(COM2_LCD_DATA[8]-1));
							 else tx2_lcd(0x46,(COM2_LCD_DATA[8]+1));
							}	COM2_LCD_DATA[0]=0x00;	 break; 												
					 } break;			
		
		
		//..........................//					
					case 0x65:		  															 	//���Ӽ�			  
					{  
					if(COM2_LCD_DATA[8]>nlval)
					{
						Send_oneline(5);}
					else 
					{
						if(COM2_LCD_DATA[8]<nlval)
						{Send_oneline(4);}			
					}
					nlval=COM2_LCD_DATA[8];									 
					if(EN_R==1||EN_B==1)
					{
						if(EN_R==1)
						PWMB_Duty.PWM5_Duty = pwm_A[nlval-1];
						if(EN_B==1)
						PWMB_Duty.PWM5_Duty = pwm_B[nlval-1];  
					}						
						 COM2_LCD_DATA[0]=0x00; break; //���ʼ�	
				}
		//************************��ͨ��*****************************************************//				
					case 0x53:		 																	//��� ����ͣ
					{				  
						switch(COM2_LCD_DATA[8])	  											
						{
							case 0x01:  		//����
							{
								if((ZHRB==1) && (Minute2==0))    break;     	//���� ʱ��Ϊ0
								if((ZHRB==2) && (RB_Minute2==0)) break;      //��Ϲ� ʱ��Ϊ0
								RUN_APP(2);
								COM2_LCD_DATA[0]=0x00;
							}  break;
							case 0x02:       //ֹͣ
							{	
								STOP_APP(2);
								COM2_LCD_DATA[0]=0x00;
							 }  break; 											                                 
							default:break;
						}
					}break;
		//..........................//	
					case 0x54:		  															 	//�������
					{  				  
						switch(COM2_LCD_DATA[8])	  
						{
							case 0x01:   //����	
									UP_DOWN_APP(2,1) ;              // ****************���ⲿ�ж�0 
									COM2_LCD_DATA[0]=0x00; break; 										 
							case 0x02:   //�½�
									UP_DOWN_APP(2,2) ;                    // ***************���ⲿ�ж�0 
									COM2_LCD_DATA[0]=0x00; break; 
																	 //�½�
									default:break;
						}
					} break;
		//..........................//	
					case 0x16:		  														    //���SECSʱ��Ӽ�1
					{
						MIN_APP(2);
						COM2_LCD_DATA[0]=0x00;	 break; 												
					 } break;	
		//..........................//					
					case 0x18:		  															 	//����Ƶ��			  
					{  
						if(Run_Flag2==0)										 
							{ Hzval2=COM2_LCD_DATA[8];
							 if(Hzval2)
								Send_oneline(12);					               	//y���� ����
							 else
								 Send_oneline(13);					             	//y����  ����
							 COM2_LCD_DATA[0]=0x00; break; 
						 }
					} break;
		//..........................//	
					case 0x19:		  															 	//������ѡ��			  
					{  
						if(Run_Flag2==0)										 
						{ 
							RB_LED_L=COM2_LCD_DATA[8];
							ZHRB_LED_L=COM2_LCD_DATA[8];
							if(RB_LED_L)
							Send_oneline(6);					                //����
							else
							Send_oneline(7);					                //���
							COM2_LCD_DATA[0]=0x00; break; 
						}
					} break;
		//..........................//
					case 0x35:		  													      //���ģʽ-���ʱ��Ӽ�1 	
					{
						if(Run_Flag2==0)				 
						 {
						 if(set_R_Minute2!=COM2_LCD_DATA[8])
							{
								if(set_R_Minute2<COM2_LCD_DATA[8]) Send_oneline(9);                            //����ʱ���
								else Send_oneline(8);                                               					//����ʱ���
								set_R_Minute2=COM2_LCD_DATA[8];
								R_Minute2=COM2_LCD_DATA[8];													                           //ʱ��� 
								R_Second2=0;
								RB_Minute2=R_Minute2+B_Minute2;
								set_RB_Minute2=RB_Minute2;							
								tx2_lcd_T(0x32,((R_Minute2/10)<<4)+(R_Minute2%10));		
								delay_100us(10);							
								tx2_lcd_T(0x34,((R_Second2/10)<<4)+(R_Second2%10));
								}
						 }
						else
							{if(set_R_Minute2<COM2_LCD_DATA[8]) tx2_lcd(0x35,(COM2_LCD_DATA[8]-1));
							 else tx2_lcd(0x35,(COM2_LCD_DATA[8]+1));
							}	COM2_LCD_DATA[0]=0x00;	 break; 												
					 } break;			
		//..........................//							
					case 0x36:		  														    //���ģʽ-����ʱ��Ӽ�1 	
					{  
						if(Run_Flag2==0)			 
						 {
						 if(Set_B_Minute2!=COM2_LCD_DATA[8])
							{
								if(Set_B_Minute2<COM2_LCD_DATA[8]) Send_oneline(9);                            //����ʱ���
								else Send_oneline(8);                                              //����ʱ���
								Set_B_Minute2 = COM2_LCD_DATA[8];
								B_Minute2 = COM2_LCD_DATA[8];													                           //ʱ��� 
								B_Second2=0; 
								RB_Minute2 = R_Minute2 + B_Minute2;
								set_RB_Minute2 = RB_Minute2;	
								tx2_lcd_T(0x37,((B_Minute2/10)<<4)+(B_Minute2%10));
								delay_100us(10);
								tx2_lcd_T(0x39,((B_Second2/10)<<4)+(B_Second2%10));							
								delay_100us(10);
								
								}    
						 }
						else
							{ 
								if(Set_B_Minute2<COM2_LCD_DATA[8]) tx2_lcd(0x36,(COM2_LCD_DATA[8]-1));
							 else tx2_lcd(0x36,(COM2_LCD_DATA[8]+1));
							}	COM2_LCD_DATA[0]=0x00;	 break; 												
					 } break;				
		
		
		//..........................//					
					case 0x55:		  															 	//��⵵λ�Ӽ�			  
					{  
						if(COM2_LCD_DATA[8]>nlval2)
						{
							Send_oneline(5);}
						else 
						{
							if(COM2_LCD_DATA[8]<nlval2)
							{Send_oneline(4);}			
						}
						nlval2=COM2_LCD_DATA[8];									 
						if(EN_R2==1||EN_B2==1)
						{
							if(EN_R2==1)
							PWMB_Duty.PWM8_Duty = pwm_A[nlval-1];
							if(EN_B2==1)
							PWMB_Duty.PWM8_Duty = pwm_B[nlval-1];  
						}						
								//P0=COM2_LCD_DATA[8];
							 COM2_LCD_DATA[0]=0x00; break; //���ʼ�	
				}
		//..........................//					
					case 0x50:		  															  //��������
					{				  
						switch(COM2_LCD_DATA[8])	  
						{
							case 0x00:speaker=1;Send_oneline(14);COM2_LCD_DATA[0]=0x00;  break; //������
							case 0x01:speaker=0; COM2_LCD_DATA[0]=0x00;break; //������
							default:break;
						}
						} break;	
		//..........................//					
					case 0x51:		  																//����˫ģʽѡ��			  
					{  									     
						if(Run_Flag==0)	                              //δ����״̬
						{ 
						 if(COM2_LCD_DATA[8]==1)		                           
							 {
								 tx2_lcd_P(1);  					  
								 ZHRB=1;  
								
								 Send_oneline(17);                         //����ģʽ	  
								tx2_lcd_T(0x22,((Minute/10)<<4)+(Minute%10));	
								delay_100us(100);	
								tx2_lcd_T(0x12,((Minute2/10)<<4)+(Minute2%10));	
								delay_100us(100);									 
							 }
						 if(COM2_LCD_DATA[8]==2)                      //��������������Ч           
							{
								tx2_lcd_P(8);                            //����ҳ��
								ZHRB=2; 
															
								Send_oneline(16);														//���ģʽ
								tx2_lcd_T(0x42,((R_Minute/10)<<4)+(R_Minute%10));
								delay_100us(100); 
								tx2_lcd_T(0x47,((B_Minute/10)<<4)+(B_Minute%10));
								delay_100us(100); 

								tx2_lcd_T(0x32,((R_Minute2/10)<<4)+(R_Minute2%10));
								delay_100us(100); 
								tx2_lcd_T(0x37,((B_Minute2/10)<<4)+(B_Minute2%10));
								delay_100us(100); 
							}
						 	
						tx2_lcd( 0x65 ,nlval );
						delay_100us(100); 
						tx2_lcd( 0x55 ,nlval2 );
						delay_100us(100); 
						}							
						COM2_LCD_DATA[0]=0x00; break;                                                     
						} break;	
				 default:break;
				} 	
			}
			CLEAN_COM2_LCD_DATA();     //������������		
			
/****************************�����л�**********************************/
			if(Run_Flag==1)			    //�����л� ,�ƹ���˸ һ��һ��
			{
				switch(Hzval)
				{
					case 0x00:
					{
						if(EN_R==1)											//������ʹ��
						PWMB_Duty.PWM5_Duty = pwm_A[nlval-1];				//PWM5ռ�ձ�Ϊpwm_A[nlval-1]��nlval����±�
						if(EN_B==1)											//�������ʹ��
						PWMB_Duty.PWM5_Duty = pwm_B[nlval-1];				//PWM5ռ�ձ�Ϊpwm_B[nlval-1]
						break;
					}																	 //***********************************************/
					case 0x01:
					{
						if(t50ms <= 10)
						{ 
							PWMB_Duty.PWM5_Duty = 0;
						}
						else
						{						
							if(EN_R==1)
							PWMB_Duty.PWM5_Duty = pwm_A[nlval-1];
							if(EN_B==1)
							PWMB_Duty.PWM5_Duty = pwm_B[nlval-1];
						}
//						UpdatePwm(PWMB, &PWMB_Duty); 
						break;
					}
				}
			}
			if(Run_Flag2==1)			    //�����л� ,�ƹ���˸ һ��һ��
			{
				switch(Hzval2)
				{
					case 0x00:
					{
						if(EN_R2==1)
						PWMB_Duty.PWM8_Duty = pwm_A[nlval2-1];
						if(EN_B2==1)
						PWMB_Duty.PWM8_Duty = pwm_B[nlval2-1];
						break;
					}																	 //***********************************************/
					case 0x01:
					{
						if(t50ms <= 10)
						{ 
							PWMB_Duty.PWM8_Duty = 0;
						}
						else
						{						
							if(EN_R2==1)
							PWMB_Duty.PWM8_Duty = pwm_A[nlval-1];
							if(EN_B2==1)
							PWMB_Duty.PWM8_Duty = pwm_B[nlval-1];
						}
//						UpdatePwm(PWMB, &PWMB_Duty); 
						break;
					}
				}
			}
	/***********************ʱ�����*********************/
			if(Run_Flag==1)			               								
			{	
				if((t50ms == 20)|(t50ms == 10))                               //����˸ ʱ�����ݸ���	
				{ 				
					if(Time_50ms_flag==1)    //��ʾð��
				 	{
						S_Flag = ~S_Flag;
						tx2_lcd_B(0x75,S_Flag);
						delay_ms(1); 
						tx2_lcd_B(0x90,S_Flag);
						delay_ms(1); 
						tx2_lcd_B(0x95,S_Flag);
						delay_ms(2); 
						Time_50ms_flag=0;
					}		
					if(S_Flag==1) //��ʾʱ�� 							//���ð����ʾ��־����1
					{ 
						if(ZHRB==1)                                                      //����ѡ������
						{ 					
							tx2_lcd_T(0x24,((Second/10)<<4)+(Second%10));					//second��minute������ģʽ����ֵ
							delay_100us(5); 
							tx2_lcd_T(0x22,((Minute/10)<<4)+(Minute%10));                   //ʱ�����ݸ���							  
						}
						if(ZHRB==2)                                                      	//���ģʽ
						{
							if (ZHRB_LED==0)                                               //���ѡ��
							{                                                              
								if(RB_Minute>=B_Minute)                                    //��Ϸ�>=�����
								{
									tx2_lcd_T(0x44,((RB_Second/10)<<4)+(RB_Second%10));
									delay_100us(10); 
									tx2_lcd_T(0x42,(((R_Minute-(set_RB_Minute-RB_Minute))/10)<<4)+((R_Minute-(set_RB_Minute-RB_Minute))%10));         //ʱ�����ݸ���
								}
								else                                                         //����ѡ��
								{
									tx2_lcd_T(0x42,0);
									delay_100us(10);
									tx2_lcd_T(0x44,0);
									delay_100us(10);					 
									tx2_lcd_T(0x49,((RB_Second/10)<<4)+(RB_Second%10));
									delay_100us(10);  					
									tx2_lcd_T(0x47,(((B_Minute-(set_RB_Minute-R_Minute-RB_Minute))/10)<<4)+((B_Minute-(set_RB_Minute-R_Minute-RB_Minute))%10));        //ʱ�����ݸ���
								}
							}	
							else                                                           //....����ѡ������
							{
								if(RB_Minute>=R_Minute)                                       //����ѡ��
									{
										tx2_lcd_T(0x49,((RB_Second/10)<<4)+(RB_Second%10));
										delay_100us(10); 					 
										tx2_lcd_T(0x47,(((B_Minute-(set_RB_Minute-RB_Minute))/10)<<4)+((B_Minute-(set_RB_Minute-RB_Minute))%10));        //ʱ�����ݸ���
									}
								else                                                         //���ѡ��
									{
										tx2_lcd_T(0x49,0); 
										delay_100us(10);  					
										tx2_lcd_T(0x44,((RB_Second/10)<<4)+(RB_Second%10));
										delay_100us(10);  					
										tx2_lcd_T(0x42,(((R_Minute-(set_RB_Minute-B_Minute-RB_Minute))/10)<<4)+((R_Minute-(set_RB_Minute-B_Minute-RB_Minute))%10));        //ʱ�����ݸ���
									}
							}  		   
						}
					}			
				}
			}	
			
		
			if(Run_Flag2==1)			               								
			{	
			 if((t50ms2 == 20)|(t50ms2 == 10))                               //����˸ ʱ�����ݸ���	
				{
					 //��ʾð��
				 if(Time_50ms_flag2==1)
				 {
					S_Flag2 = ~S_Flag2;
					tx2_lcd_B(0x70,S_Flag2);
					delay_ms(1); 
					tx2_lcd_B(0x80,S_Flag2);
					delay_ms(1); 
					tx2_lcd_B(0x85,S_Flag2);
					delay_ms(1); 
					Time_50ms_flag2=0;
				 }
			 
				//��ʾʱ�� 
				if(S_Flag2==1) 
				 { 
					 if(ZHRB==1)                                                      //....����ѡ������
					 { 					
						tx2_lcd_T(0x14,((Second2/10)<<4)+(Second2%10));
						delay_100us(5); 
						tx2_lcd_T(0x12,((Minute2/10)<<4)+(Minute2%10));                    //ʱ�����ݸ���							  
					 }
					if(ZHRB==2) 
					 {
						 if (ZHRB_LED_L==0)
						 {
							 if(RB_Minute2>=B_Minute2)                                      //���ѡ��
								{
								 tx2_lcd_T(0x34,((RB_Second2/10)<<4)+(RB_Second2%10));
								 delay_100us(10); 
								 tx2_lcd_T(0x32,(((R_Minute2-(set_RB_Minute2-RB_Minute2))/10)<<4)+((R_Minute2-(set_RB_Minute2-RB_Minute2))%10));         //ʱ�����ݸ���
								}
								else                                                         //����ѡ��
								{
									tx2_lcd_T(0x32,0);
									delay_100us(10);
									tx2_lcd_T(0x34,0);
									delay_100us(10);					 
									tx2_lcd_T(0x39,((RB_Second2/10)<<4)+(RB_Second2%10));
									delay_100us(10);  					
									tx2_lcd_T(0x37,(((B_Minute2-(set_RB_Minute2-R_Minute2-RB_Minute2))/10)<<4)+((B_Minute2-(set_RB_Minute2-R_Minute2-RB_Minute2))%10));        //ʱ�����ݸ���
								}
							}	
							 else                                                           //....����ѡ������
								{
								 if(RB_Minute2>=R_Minute2)                                       //����ѡ��
									 {
											tx2_lcd_T(0x39,((RB_Second2/10)<<4)+(RB_Second2%10));
											delay_100us(10); 					 
											tx2_lcd_T(0x37,(((B_Minute2-(set_RB_Minute2-RB_Minute2))/10)<<4)+((B_Minute2-(set_RB_Minute2-RB_Minute2))%10));        //ʱ�����ݸ���
									 }
								 else                                                         //���ѡ��
									 {
											tx2_lcd_T(0x39,0); 
											delay_100us(10);  					
											tx2_lcd_T(0x34,((RB_Second2/10)<<4)+(RB_Second2%10));
											delay_100us(10);  					
											tx2_lcd_T(0x32,(((R_Minute2-(set_RB_Minute2-B_Minute2-RB_Minute2))/10)<<4)+((R_Minute2-(set_RB_Minute2-B_Minute2-RB_Minute2))%10));        //ʱ�����ݸ���
									 }
								}  		   
					 }
				 }			
			 }	
			}		
	//................//		
	/************************����ģʽֹͣ����********************************/	 
			if (Time_Stop_flag==1)   
			{ 
				STOP_APP(3);
				Time_Stop_flag=0;
			}
			if (Time_Stop_flag2==1)   
			{ 
				STOP_APP(4);
				Time_Stop_flag2=0;
			}
	//................//	
	/************************���ģʽֹͣ����*****************************/	
			if(Time_RB_Stop_flag==1) 
			{  		                                                 
				STOP_APP(5);
				Time_RB_Stop_flag=0;	
			}	
			if(Time_RB_Stop_flag2==1) 
			{  		                                                 
				STOP_APP(6);
				Time_RB_Stop_flag2=0;		
			}	
		}
	}
}

void STOP_APP(u8 LEFT_OR_RIGHT)					//ֹͣappģʽ��6��
{
	if(LEFT_OR_RIGHT==1)
	{
		PWMB_Duty.PWM5_Duty =0;  
		EN_R=0;
		EN_B=0; 							
		tx2_lcd_B(0x75,1);                        //��ʾ��������
		Send_oneline(1);                         	//y����
		Run_Flag=0;
		Stop_flag=1;                                	//ֹͣ��־λ����ʾ�趨ʱ��
//		Time_RB_Stop_flag=1; 
	}
	if(LEFT_OR_RIGHT==2)
	{
		PWMB_Duty.PWM8_Duty =0;  
		EN_R2=0;
		EN_B2=0; 							
		tx2_lcd_B(0x70,1);                        //��ʾ��������
		Send_oneline(1);                         	//y����
		Run_Flag2=0;
		Stop_flag2=1;                                	//ֹͣ��־λ����ʾ�趨ʱ��
//		Time_RB_Stop_flag2=1; 
	}
	if(LEFT_OR_RIGHT==3)   //ʱ������������
	{
		PWMB_Duty.PWM5_Duty =0;  
		EN_R=0;
		EN_B=0; 
		Minute = Set_Minute;
		tx2_lcd_T(0x22,((Set_Minute/10)<<4)+(Set_Minute%10));
		delay_ms(1);
		tx2_lcd_T(0x24,0);	
		delay_ms(1);
		tx2_lcd_B(0x75,1);                        //��ʾ��������
		tx2_lcd(0x26,Set_Minute);									//������ֵ	
		Send_oneline(1);                         	//y����
		Run_Flag=0;
		Stop_flag=1;                                	//ֹͣ��־λ����ʾ�趨ʱ��
//		Time_RB_Stop_flag=1; 
	}
	if(LEFT_OR_RIGHT==4)   //ʱ���������ʾ���ò���
	{
		PWMB_Duty.PWM8_Duty =0;  
		EN_R2=0;
		EN_B2=0;
		Minute2 = Set_Minute2;
		tx2_lcd_T(0x12,((Set_Minute2/10)<<4)+(Set_Minute2%10));
		tx2_lcd(0x16,Set_Minute2);									//������ֵ
		delay_ms(1);		
		tx2_lcd_T(0x14,0);	
		delay_ms(1);		
		tx2_lcd_B(0x70,1);                        //��ʾ��������
		Send_oneline(1);                         	//y����
		Run_Flag2=0;
		Stop_flag2=1;                                	//ֹͣ��־λ����ʾ�趨ʱ��
//		Time_RB_Stop_flag2=1; 
	}
	if(LEFT_OR_RIGHT==5)       //���ģʽʱ�����
	{  
		PWMB_Duty.PWM5_Duty =0;  
		EN_R=0; 
		EN_B=0; 
//				TR0=0;          //ֹͣ��ʱ��  
		Send_oneline(1);//y����
		Time_RB_Stop_flag=0; 
		Run_Flag=0;
		Stop_flag=1;                                	//ֹͣ��־λ����ʾ�趨ʱ��					
		RB_Minute=set_RB_Minute;
		R_Minute=set_R_Minute;
		B_Minute=set_B_Minute;			
		RB_Second = 0;			
		tx2_lcd_T(0x44,0);
		delay_100us(10);
		tx2_lcd_T(0x49,0);
		delay_100us(10); 
		tx2_lcd_T(0x42,((R_Minute/10)<<4)+(R_Minute%10));
		tx2_lcd(0x45,R_Minute);									//������ֵ
		delay_100us(10); 
		tx2_lcd_T(0x47,((B_Minute/10)<<4)+(B_Minute%10));	
		tx2_lcd(0x46,B_Minute);									//������ֵ
	}
	if(LEFT_OR_RIGHT==6)
	{ 
		PWMB_Duty.PWM8_Duty =0; ;  
		EN_R2=0; 
		EN_B2=0; 
//		TR0=0;          //ֹͣ��ʱ��  
		Send_oneline(1);//y����
		Time_RB_Stop_flag2=0; 
		Run_Flag2=0;
		Stop_flag2=1;                                	//ֹͣ��־λ����ʾ�趨ʱ��		
		RB_Minute2=set_RB_Minute2;
		R_Minute2=set_R_Minute2;
		B_Minute2=Set_B_Minute2;			
		RB_Second2 = 0;			
		tx2_lcd_T(0x34,0);tx2_lcd_T(0x39,0);
		delay_100us(10); 
		tx2_lcd_T(0x32,((R_Minute2/10)<<4)+(R_Minute2%10));
		tx2_lcd(0x35,R_Minute);									//������ֵ
		delay_100us(10); 
		tx2_lcd_T(0x37,((B_Minute2/10)<<4)+(B_Minute2%10));	
		tx2_lcd(0x36,B_Minute);									//������ֵ		
	}
}

void RUN_APP(u8 LEFT_OR_RIGHT)						//����appģʽ����
{
	if(LEFT_OR_RIGHT==1)										//ʵ��	LEFT_OR_RIGHT:1	�ұ�			LEFT_OR_RIGHT:2 ���
	{ 		
		if(RB_LED)  //tmp[3]                   		//  ������ѡ��
		{	
			PWMB_Duty.PWM5_Duty = pwm_B[nlval-1];
			EN_B=1;
		}
		else                   										// �����ѡ��
		{
			PWMB_Duty.PWM5_Duty = pwm_A[nlval-1];
			EN_R=1;
		}
		UpdatePwm(PWMB, &PWMB_Duty); 													 
		TR0=1;  
		t50ms=20;
		Send_oneline(0);                     //y����
		Run_Flag=1;
		Write_EEPDATA();                     //д��eprom  	
	} 
	if(LEFT_OR_RIGHT==2)
	{
		if(RB_LED_L)  //tmp[3]                   		//  ������ѡ��
		{	
			PWMB_Duty.PWM8_Duty = pwm_B[nlval2-1];
			EN_B2=1;
		}
		else                   										// �����ѡ��
		{
			PWMB_Duty.PWM8_Duty = pwm_A[nlval2-1];
			EN_R2=1;
		}
															 
		TR0=1;  
		t50ms2=20;
		Send_oneline(0);                     //y����
		Run_Flag2=1;
		Write_EEPDATA();                     //д��eprom
	}
}

void UP_DOWN_APP(u8 LEFT_OR_RIGHT,u8 UP_OR_DOWN)						//�������APP
{
	if((LEFT_OR_RIGHT==1)&&(UP_OR_DOWN==1))
	{
		EX0 = 0;             // ************�ر��ⲿ�ж�0  
		if(moto_up==1)
		{	
			moto_down=0;moto_up=1;moto_en=1; 
			C50ms	= 10;						
			Timer4_Run(); 						
		}
		else
		{	
			Send_oneline(2); 
			moto_down=0;moto_up=1;moto_en=1; 						
			C50ms	= 20;						
			Timer4_Run();												
		}
		EX0 = 1;                             // ****************���ⲿ�ж�0 
	}
	if((LEFT_OR_RIGHT==1)&&(UP_OR_DOWN==2))
	{
		EX0 = 0;            // ********************�ر��ⲿ�ж�0 
		if(moto_down==1)
		{   
			moto_up=0;moto_down=1;moto_en=1; 
			C50ms	= 10;						
			Timer4_Run();
		}
		else
		{	
			Send_oneline(3);
			moto_up=0;moto_down=1;moto_en=1;
			C50ms	= 20;						
			Timer4_Run();
								
		}
		EX0 = 1;                              // ***************���ⲿ�ж�0 
	}
	if((LEFT_OR_RIGHT==2)&&(UP_OR_DOWN==1))
	{
		EX0 = 0;             // ************�ر��ⲿ�ж�0  
		if(moto_up2==1)
		{	
			moto_down2=0;moto_up2=1;moto_en2=1; 
			C50ms	= 10;						
			Timer4_Run(); 						
		}
		else
		{	
			Send_oneline(2); 
			moto_down2=0;moto_up2=1;moto_en2=1; 						
			C50ms	= 20;						
			Timer4_Run();												
		}
		EX0 = 1;                             // ****************���ⲿ�ж�0 
	}
	if((LEFT_OR_RIGHT==2)&&(UP_OR_DOWN==2))
	{
		EX0 = 0;            // ********************�ر��ⲿ�ж�0 
		if(moto_down2==1)
		{   
			moto_up2=0;moto_down2=1;moto_en2=1; 
			C50ms	= 10;						
			Timer4_Run();
		}
		else
		{	
			Send_oneline(3);
			moto_up2=0;moto_down2=1;moto_en2=1;
			C50ms	= 20;						
			Timer4_Run();
								
		}
		EX0 = 1;                              // ***************���ⲿ�ж�0 
	}
}
void MIN_APP(u8 LEFT_OR_RIGHT)						//����APP
{ 
	if((LEFT_OR_RIGHT==1))
	{
		if(Run_Flag==0)				 
		{
		 if(Set_Minute < COM2_LCD_DATA[8])
			{
				Send_oneline(9);                            //����ʱ���
				Second=0; 
				Set_Minute=COM2_LCD_DATA[8];//Set_Minute++; 
				if(Set_Minute>99)  Set_Minute=99;				  	  	
				Minute=Set_Minute; 				
			}
			else
			{ 
				Send_oneline(8);
				Second=0; 
				Set_Minute=COM2_LCD_DATA[8];//Set_Minute--; 
				if(Set_Minute==0) Set_Minute=0;		  
				Minute=Set_Minute; 
			}
			
				tx2_lcd_T(0x22,((Minute/10)<<4)+(Minute%10));	
				delay_100us(10);
				tx2_lcd_T(0x24,((Second/10)<<4)+(Second%10));
		}
		else
		{
			if(Set_Minute<COM2_LCD_DATA[8]) tx2_lcd(0x22,(COM2_LCD_DATA[8]-1));
			else tx2_lcd(0x22,(COM2_LCD_DATA[8]+1));
		}	
	}
	if((LEFT_OR_RIGHT==2))
	{
		if(Run_Flag2==0)				 
		{
		 if(Set_Minute2 < COM2_LCD_DATA[8])
			{
				Send_oneline(9);                            //����ʱ���
				Second2=0; 
				Set_Minute2=COM2_LCD_DATA[8];//Set_Minute2++; 
				if(Set_Minute2>99)  Set_Minute2=99;				  	  	
				Minute2=Set_Minute2; 				
			}
			else
			{ 
				Send_oneline(8);
				Second=0; 
				Set_Minute2=COM2_LCD_DATA[8];//Set_Minute2--; 
				if(Set_Minute2==0) Set_Minute2=0;		  
				Minute2=Set_Minute2; 
			}
			
				tx2_lcd_T(0x12,((Minute2/10)<<4)+(Minute2%10));	
				delay_100us(10);
				tx2_lcd_T(0x14,((Second2/10)<<4)+(Second2%10));
		 }
		else
		{
			if(Set_Minute<COM2_LCD_DATA[8]) tx2_lcd(0x12,(COM2_LCD_DATA[8]-1));
			else tx2_lcd(0x12,(COM2_LCD_DATA[8]+1));
		}	
	}  
}



//�������������
void cmd_feedback(void)
{
	if(RX4_Buffer[0] == 0xfe)							//��һλΪ0xfe����������֡ͷ��ȷ��
	{
		if(RX4_Buffer[4] == 0xff)
		{
			if(RX4_Buffer[1] == 0x01)					//��һλΪ0x01�������������
			{
					switch(RX4_Buffer[2])
					{					
						case 0x10:										//�������+				
							if(RB_LED_L == 0)							//����
							{
								nlval2++;
								if(nlval2 >= 6)
								{
									nlval2 = 6;
								}
								PWMB_Duty.PWM8_Duty = pwm_A[nlval2-1];
								tx2_lcd(0x55,nlval2);
								Send_oneline(5);
/************�Զ�����������⣬������λ������pwm����λ�����������nlval����pwmֵ*************/
//								left_pwm_A_num++;
//								if(left_pwm_A_num >= 5)
//								{
//									left_pwm_A_num = 5;
//								}
//								PWMB_Duty.PWM8_Duty = pwm_A[left_pwm_A_num];
							}
							else if(RB_LED_L == 1)				//������
							{
								nlval2++;
								if(nlval2 >= 6)
								{
									nlval2 = 6;
								}
								PWMB_Duty.PWM8_Duty = pwm_B[nlval2-1];
								tx2_lcd(0x55,nlval2);
								Send_oneline(5);
							}
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							//RUN_APP(2);
							break;
						case 0x11:										//�������-
							if(RB_LED_L == 0)							//����
							{
								nlval2--;
								if(nlval2 <= 1)
								{
									nlval2 = 1;
								}
								PWMB_Duty.PWM8_Duty = pwm_A[nlval2-1];
								tx2_lcd(0x55,nlval2);
								Send_oneline(4);
							}
							else if(RB_LED_L == 1)				//������
							{
								nlval2--;
								if(nlval2 <= 1)
								{
									nlval2 = 1;
								}
								PWMB_Duty.PWM8_Duty = pwm_B[nlval2-1];
								tx2_lcd(0x55,nlval2);
								Send_oneline(4);
							}
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							//RUN_APP(2);
							break;
						case 0x12:										//��������
							UP_DOWN_APP(2,1);
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							break;
						case 0x13:										//�����½�
							UP_DOWN_APP(2,2);
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							break;
						case 0x14:										//��ʱ��+	
							if(Run_Flag2==0)
							{
								Minute2++;
								if(Minute2 >= 99) Minute2 = 99;
								Second2 = 0;
								tx2_lcd_T(0x12,((Minute2/10)<<4)+(Minute2%10));
								Send_oneline(9);
							}
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							break;
						case 0x15:										//��ʱ��-
							if(Run_Flag2==0)
							{
								Minute2--;
								if(Minute2 <= 0) Minute2 = 0;
								Second2 = 0;
								tx2_lcd_T(0x12,((Minute2/10)<<4)+(Minute2%10));
								Send_oneline(8);
							}
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							break;	
						case 0x16:										//����ѡ��
							RB_LED_L = 0;
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							Send_oneline(7);
							//RUN_APP(2);	
							break;		
						case 0x17:										//������ѡ��			//��Ҫ������ֹͣcase 0x19�����л�������
							RB_LED_L = 1;
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							Send_oneline(6);
							//RUN_APP(2);	
							break;	
						case 0x18:										//������
							RUN_APP(2);	
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							break;	
						case 0x19:										//��ֹͣ	
							STOP_APP(2);
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							break;	
					}	
			}	
			else if(RX4_Buffer[1] == 0x02)
			{
				switch(RX4_Buffer[2])
					{					
						case 0x10:										//�ҹ�����+			
							if(RB_LED == 0)							//�Һ��
							{
								nlval++;
								if(nlval >= 6)
								{
									nlval = 6;
								}
								PWMB_Duty.PWM5_Duty = pwm_A[nlval-1];
								tx2_lcd(0x65,nlval);
								Send_oneline(5);
//								right_pwm_A_num++;
//								if(right_pwm_A_num >= 5)
//								{
//									right_pwm_A_num = 5;
//								}
//								PWMB_Duty.PWM5_Duty = pwm_A[right_pwm_A_num];
							}
							else if(RB_LED == 1)				//������
							{
								nlval++;
								if(nlval >= 6)
								{
									nlval = 6;
								}
								PWMB_Duty.PWM5_Duty = pwm_B[nlval-1];
								tx2_lcd(0x65,nlval);
								Send_oneline(5);
//								right_pwm_B_num++;
//								if(right_pwm_B_num >= 5)
//								{
//									right_pwm_B_num = 5;
//								}
//								PWMB_Duty.PWM5_Duty = pwm_B[right_pwm_B_num];
							}
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							//RUN_APP(1);
							break;
						case 0x11:										//�ҹ�����-
							if(RB_LED == 0)							//�Һ��
							{
								nlval--;
								if(nlval <= 1)
								{
									nlval = 1;
								}
								PWMB_Duty.PWM5_Duty = pwm_A[nlval-1];
								tx2_lcd(0x65,nlval);
								Send_oneline(4);
//								right_pwm_A_num--;
//								if(right_pwm_A_num <= 0)
//								{
//									right_pwm_A_num = 0;
//								}
//								PWMB_Duty.PWM5_Duty = pwm_A[right_pwm_A_num];
							}
							else if(RB_LED == 1)				//������
							{
								nlval--;
								if(nlval <= 1)
								{
									nlval = 1;
								}
								PWMB_Duty.PWM5_Duty = pwm_B[nlval-1];
								tx2_lcd(0x65,nlval);														//ͬ���ϴ���������
								Send_oneline(4);																//����-	
//								right_pwm_B_num--;
//								if(right_pwm_B_num <= 0)
//								{
//									right_pwm_B_num = 0;
//								}
//								PWMB_Duty.PWM5_Duty = pwm_B[right_pwm_B_num];
							}
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							//RUN_APP(1);
							break;
						case 0x12:										//�ҵ������
							UP_DOWN_APP(1,1);
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							break;
						case 0x13:										//�ҵ���½�
							UP_DOWN_APP(1,2);
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							break;
						case 0x14:										//��ʱ��+				
							if(Run_Flag==0)
							{
								Minute++;
								if(Minute >= 99) Minute = 99;
								Second = 0;
								tx2_lcd_T(0x22,((Minute/10)<<4)+(Minute%10));
								Send_oneline(9);
							}
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							break;
						case 0x15:										//��ʱ��-
							if(Run_Flag==0)
							{
								Minute--;
								if(Minute <= 0) Minute = 0;
								Second = 0;
								tx2_lcd_T(0x22,((Minute/10)<<4)+(Minute%10));
								Send_oneline(8);
							}
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							break;						
						case 0x16:										//�Һ��ѡ��
							RB_LED = 0;
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							Send_oneline(7);
							//RUN_APP(1);	
							break;		
						case 0x17:										//������ѡ��			//��Ҫ������ֹͣcase 0x19�����л�������
							RB_LED = 1;
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							Send_oneline(6);
							//RUN_APP(1);	
							break;	
						case 0x18:										//������
							RUN_APP(1);	
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							break;	
						case 0x19:										//��ֹͣ	
							STOP_APP(1);
							RX4_Buffer[0] = 0;
							RX4_Buffer[1] = 0;
							RX4_Buffer[2] = 0;
							RX4_Buffer[3] = 0;
							RX4_Buffer[4] = 0;
							break;	
					}	
						
			}
			else if(RX4_Buffer[1] == 0x03)
			{
				switch(RX4_Buffer[2])
				{
					case 0x01:											//��/˫ģʽ�л�
						if(RFID_SHANGCHUAN_FLAG ==1)
						{
							if(RX4_Buffer[3] == 0x01)			//��ģʽ
							{
								tx2_lcd_P(1);
								ZHRB=1;  									
								Send_oneline(17);
							}
							else if(RX4_Buffer[3] == 0x02)	//˫ģʽ
							{
								tx2_lcd_P(8);
								ZHRB=2; 							
								Send_oneline(16);		
							}
						}
						RX4_Buffer[0] = 0;
						RX4_Buffer[1] = 0;
						RX4_Buffer[2] = 0;
						RX4_Buffer[3] = 0;
						RX4_Buffer[4] = 0;
						break;
					case 0x02:
						if(RFID_SHANGCHUAN_FLAG ==1)
						{
							if(RX4_Buffer[3] == 0x01)					//��Ƶ��
							{
								Hzval2 = 1;
								Send_oneline(12);
								tx2_lcd(0x18,Hzval2);
							}
							else if(RX4_Buffer[3] == 0x02)		//������
							{
								Hzval2 = 0;
								Send_oneline(13);
								tx2_lcd(0x18,Hzval2);
							}
						}
						RX4_Buffer[0] = 0;
						RX4_Buffer[1] = 0;
						RX4_Buffer[2] = 0;
						RX4_Buffer[3] = 0;
						RX4_Buffer[4] = 0;
						break;
					case 0x03:
						if(RFID_SHANGCHUAN_FLAG ==1)
						{
							if(RX4_Buffer[3] == 0x01)					//��Ƶ��
							{
								Hzval = 1;
								Send_oneline(12);
								tx2_lcd(0x28,Hzval);
							}
							else if(RX4_Buffer[3] == 0x02)		//������
							{
								Hzval = 0;
								Send_oneline(13);
								tx2_lcd(0x28,Hzval);
							}
						}
						RX4_Buffer[0] = 0;
						RX4_Buffer[1] = 0;
						RX4_Buffer[2] = 0;
						RX4_Buffer[3] = 0;
						RX4_Buffer[4] = 0;
						break;
					case 0x10:													//����ʱ��+
						if(Run_Flag2==0)
						{
							R_Minute2++;
							if(R_Minute2 >= 99) R_Minute2 = 99;
							R_Second2 = 0;
							RB_Minute2 = R_Minute2 + B_Minute2;
							set_RB_Minute2 = RB_Minute2;
		
							tx2_lcd_T(0x32,((R_Minute2/10)<<4)+(R_Minute2%10));		
							delay_100us(10);							
							tx2_lcd_T(0x34,((R_Second2/10)<<4)+(R_Second2%10));
							Send_oneline(9);
						}
						RX4_Buffer[0] = 0;
						RX4_Buffer[1] = 0;
						RX4_Buffer[2] = 0;
						RX4_Buffer[3] = 0;
						RX4_Buffer[4] = 0;
						break;
					case 0x11:													//����ʱ��-
						if(Run_Flag2==0)
						{
							R_Minute2--;
							if(R_Minute2 <= 0) R_Minute2 = 0;
							R_Second2 = 0;
							RB_Minute2 = R_Minute2 + B_Minute2;
							set_RB_Minute2 = RB_Minute2;
						
							Send_oneline(8);
							tx2_lcd_T(0x32,((R_Minute2/10)<<4)+(R_Minute2%10));		
							delay_100us(10);							
							tx2_lcd_T(0x34,((R_Second2/10)<<4)+(R_Second2%10));
						}
						RX4_Buffer[0] = 0;
						RX4_Buffer[1] = 0;
						RX4_Buffer[2] = 0;
						RX4_Buffer[3] = 0;
						RX4_Buffer[4] = 0;
						break;
					case 0x12:													//������ʱ��+
						if(Run_Flag2==0)
						{
							B_Minute2++;
							if(B_Minute2 >= 99) B_Minute2 = 99;
							B_Second2 = 0;
							RB_Minute2 = R_Minute2 + B_Minute2;
							set_RB_Minute2 = RB_Minute2;
		
							tx2_lcd_T(0x37,((B_Minute2/10)<<4)+(B_Minute2%10));		
							delay_100us(10);							
							tx2_lcd_T(0x39,((B_Second2/10)<<4)+(B_Second2%10));
							Send_oneline(9);
						}
						RX4_Buffer[0] = 0;
						RX4_Buffer[1] = 0;
						RX4_Buffer[2] = 0;
						RX4_Buffer[3] = 0;
						RX4_Buffer[4] = 0;
						break;
					case 0x13:													//������ʱ��-
						if(Run_Flag2==0)
						{
							B_Minute2--;
							if(B_Minute2 <= 0) B_Minute2 = 0;
							B_Second2 = 0;
							RB_Minute2 = R_Minute2 + B_Minute2;
							set_RB_Minute2 = RB_Minute2;
		
							tx2_lcd_T(0x37,((B_Minute2/10)<<4)+(B_Minute2%10));		
							delay_100us(10);							
							tx2_lcd_T(0x39,((B_Second2/10)<<4)+(B_Second2%10));
							Send_oneline(8);
						}
						RX4_Buffer[0] = 0;
						RX4_Buffer[1] = 0;
						RX4_Buffer[2] = 0;
						RX4_Buffer[3] = 0;
						RX4_Buffer[4] = 0;
						break;
					case 0x14:													//�Һ��ʱ��+
						if(Run_Flag==0)
						{
							R_Minute++;
							if(R_Minute >= 99) R_Minute = 99;
							R_Second = 0;
							RB_Minute = R_Minute + B_Minute;
							set_RB_Minute = RB_Minute;
		
							tx2_lcd_T(0x42,((R_Minute/10)<<4)+(R_Minute%10));		
							delay_100us(10);							
							tx2_lcd_T(0x44,((R_Second/10)<<4)+(R_Second%10));
							Send_oneline(9);
						}
						RX4_Buffer[0] = 0;
						RX4_Buffer[1] = 0;
						RX4_Buffer[2] = 0;
						RX4_Buffer[3] = 0;
						RX4_Buffer[4] = 0;
						break;
					case 0x15:													//�Һ��ʱ��-
						if(Run_Flag==0)
						{
							R_Minute--;
							if(R_Minute <= 0) R_Minute = 0;
							R_Second = 0;
							RB_Minute = R_Minute + B_Minute;
							set_RB_Minute = RB_Minute;
						
							Send_oneline(8);
							tx2_lcd_T(0x42,((R_Minute/10)<<4)+(R_Minute%10));		
							delay_100us(10);							
							tx2_lcd_T(0x44,((R_Second/10)<<4)+(R_Second%10));
						}
						RX4_Buffer[0] = 0;
						RX4_Buffer[1] = 0;
						RX4_Buffer[2] = 0;
						RX4_Buffer[3] = 0;
						RX4_Buffer[4] = 0;
						break;
					case 0x16:													//������ʱ��+
						if(Run_Flag==0)
						{
							B_Minute++;
							if(B_Minute >= 99) B_Minute = 99;
							B_Second = 0;
							RB_Minute = R_Minute + B_Minute;
							set_RB_Minute = RB_Minute;
		
							tx2_lcd_T(0x47,((B_Minute/10)<<4)+(B_Minute%10));		
							delay_100us(10);							
							tx2_lcd_T(0x49,((B_Second/10)<<4)+(B_Second%10));
							Send_oneline(9);
						}
						RX4_Buffer[0] = 0;
						RX4_Buffer[1] = 0;
						RX4_Buffer[2] = 0;
						RX4_Buffer[3] = 0;
						RX4_Buffer[4] = 0;
						break;
					case 0x17:													//������ʱ��-
						if(Run_Flag==0)
						{
							B_Minute--;
							if(B_Minute <= 0) B_Minute = 0;
							B_Second = 0;
							RB_Minute = R_Minute + B_Minute;
							set_RB_Minute = RB_Minute;
		
							tx2_lcd_T(0x47,((B_Minute/10)<<4)+(B_Minute%10));		
							delay_100us(10);							
							tx2_lcd_T(0x49,((B_Second/10)<<4)+(B_Second%10));
							Send_oneline(8);
						}
						RX4_Buffer[0] = 0;
						RX4_Buffer[1] = 0;
						RX4_Buffer[2] = 0;
						RX4_Buffer[3] = 0;
						RX4_Buffer[4] = 0;
						break;
				}	
			}
		}
	}
}

/***************��ȡ����¶�ͨ������4���ͣ��ͻ�ȡ�ҹ��¶�ͨ������4����
//��ȡ����¶�ͨ������4����
void Send_Left_Temp(void)
{
	u16 res;
	u8 temp_high ,temp_low;
	u8 temp[2];
	res = Get_ADCResult(12);							//���adcֵ

	temp_high = res/256;	
	temp_low = res%256;
	temp[0] = temp_high;
	temp[1] = temp_low;
	PrintString4(temp);
}

//��ȡ�ҹ��¶�ͨ������4����
void Send_Right_Temp(void)
{
	u16 res;
	u8 temp_high ,temp_low;
	u8 temp[2];
	res = Get_ADCResult(13);							//���adcֵ

	temp_high = res/256;	
	temp_low = res%256;
	temp[0] = temp_high;
	temp[1] = temp_low;
	PrintString4(temp);
}
*****************/




//��ȡ���������¶�ͨ������4����
void Send_Temp(void)
{
		u8 res;
		res = Get_Temp_L();
		lr_temp[0] = res;
		res = Get_Temp_R();
		lr_temp[1] = res;
	/***********
		res = Get_ADCResult(12);							//���adcֵ
		left_temp_high = res/256;	
		left_temp_low = res%256;
		temp[0] = left_temp_high;
		temp[1] = left_temp_low;
		
		res = Get_ADCResult(13);							//�ҹ�adcֵ
		right_temp_high = res/256;	
		right_temp_low = res%256;
		temp[2] = right_temp_high;
		temp[3] = right_temp_low;
	*************/
	
		//���������¶�ֵ
		//PrintString4(lr_temp);
		TX4_write2buff(lr_temp[0]);
		TX4_write2buff(lr_temp[1]);
	
}

